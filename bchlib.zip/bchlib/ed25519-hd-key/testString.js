
function isValid(str){
    let arr = str.split('/')
    if(arr.length < 2) {
        return false
    }
    if(arr[0] !=='m') {
        return false
    }
    for(let i = 1; i < arr.length; i++){
        const item = arr[i]
        if (item[item.length - 1] !== "'"){
            return false
        }
        if(isNaN(item.slice(0, -1))){
            return false
        }
    }
    return true
}

const arr = [
    "m/0'",
    "m/12345'",
    "m/0'/0'/0'/0'",
    "m/11'/22'/33'/33'",
    "m/hello'",
    "m/0'/2147483647'",
]
for(let item of arr){
    console.log(isValid(item));
}
