
/*
    This is obviously a bad programming practice,
    but it is used extensively in solana
*/
function test() {
    const Student = class Person {
    }
    console.log(new Student())
    console.log(Student.name) // Person
    // console.log(new Person())
}

test()
