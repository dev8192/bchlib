/*
    exponential backoff ?
*/

function test1() {
    for (let i = 0; i < 10; i++) {
        console.log(2000 * (i + 1))
    }
}

async function test() {
    for (let i = 0; i < 10; i++) {
        const timeout = 2000 * (i + 1)
        console.log(timeout)
        await new Promise(resolve => setTimeout(resolve, timeout))
    }
}

test()
