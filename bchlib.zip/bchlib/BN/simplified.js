/*
    Simplified implementation of BN
*/
class BN {
    static wordSize = 26
    isBN(num) {
        if (num instanceof BN) {
            return true
        }
        return (
            num !== null && 
            typeof num === 'object' &&
            num.constructor.wordSize === BN.wordSize && 
            Array.isArray(num.words)
        )
    }
}
