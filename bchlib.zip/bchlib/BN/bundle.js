/*
    This program shows how BN is exposed inside the bundle
*/

var bn$1 = { exports: {} };

var bn = bn$1.exports;

var hasRequiredBn;

function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function requireBn() {
    if (hasRequiredBn) return bn$1.exports;
    hasRequiredBn = 1;
    (function (module) {
        (function (module, exports) {
            const num1 = 111
            module.exports = num1
        })(module, bn);
    }(bn$1));
    return bn$1.exports;
}

var bnExports = requireBn();
var BN = getDefaultExportFromCjs(bnExports);
console.log(BN)
