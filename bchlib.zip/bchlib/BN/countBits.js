/*
    Count leading zeros
*/

function countBits1(w) {
    // return 32 - Math.clz32(w)
    return Math.clz32(w)
}

function countBits2(w) {
    var t = w
    var r = 0
    if (t >= 0x1000) {
        r += 13
        t >>>= 13
    }
    if (t >= 0x40) {
        r += 7
        t >>>= 7
    }
    if (t >= 0x8) {
        r += 4
        t >>>= 4
    }
    if (t >= 0x02) {
        r += 2
        t >>>= 2
    }
    return r + t
}

function test1() {
    console.log(countBits1(0b111))
    console.log(countBits2(0b111))
}

function test() {
    for (let i = 1; i <= 53; i++) {
        const num = parseInt('1'.repeat(i), 2)
        console.log(countBits1(num), countBits2(num))
    }
}

test()
