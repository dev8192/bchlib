
function test1() {
    console.log(((1 << 1) - 1).toString(2))
    console.log(((1 << 2) - 1).toString(2))
    console.log(((1 << 3) - 1).toString(2))
    console.log(((1 << 4) - 1).toString(2))
    console.log(((1 << 5) - 1).toString(2))
}

/*
111111111111111111111111111111
-10000000000000000000000000000001

0b01111111111111111111111111111111
0b10000000000000000000000000000000 >> 1
0b01000000000000000000000000000000 >> 1

(Number.MAX_SAFE_INTEGER).toString(2)
0b0000000000011111111111111111111111111111111111111111111111111111


*/
function test1() {
    for (let i = 1; i <= 40; i++) {
        console.log(((1 << i) - 1).toString(2))
    }
}

function test() {
    for (let i = 1; i <= 53; i++) {
        // console.log('1'.repeat(i))
        console.log(parseInt('1'.repeat(i), 2))
        // console.log(parseInt('1'.repeat(i), 2).toString(2))
    }
}

test()
