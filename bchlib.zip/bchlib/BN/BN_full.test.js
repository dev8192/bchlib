/*

MPrime
    K256
    P224
    P192
    P25519

Red
    Mont

*/
function test1() {
    console.log(BN.isBN(123))
}

function test1() {
    const bn = new BN()
    console.log(bn)
}

function test() {
    console.log(BN._prime('k256'))
    console.log(BN._prime('p224'))
    console.log(BN._prime('p192'))
    console.log(BN._prime('p25519'))
}

function test1() {
}

function test1() {
}

function test1() {
}

function test1() {
}

function test1() {
}

test()
