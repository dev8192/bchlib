const { Connection, Keypair, PublicKey, Transaction, SystemProgram } = require('@solana/web3.js');

async function consolidateWallets() {
    const connection = new Connection('https://api.mainnet-beta.solana.com', 'confirmed');

    // CONFIG: Add your wallets here
    const sourcePrivateKeys = [
        Uint8Array.from([/* wallet1 64-byte private key */]),
        Uint8Array.from([/* wallet2 64-byte private key */]),
        // Add more...
    ];

    const destinationPubkey = new PublicKey('YOUR_DESTINATION_WALLET_ADDRESS');

    console.log(`Draining ${sourcePrivateKeys.length} wallets to ${destinationPubkey.toBase58()}`);

    for (let i = 0; i < sourcePrivateKeys.length; i++) {
        const fromKeypair = Keypair.fromSecretKey(sourcePrivateKeys[i]);
        console.log(`\n--- Wallet ${i + 1}: ${fromKeypair.publicKey.toBase58()} ---`);

        try {
            const balance = await connection.getBalance(fromKeypair.publicKey);
            if (balance === 0) {
                console.log('Empty, skipping');
                continue;
            }

            console.log(`Balance: ${(balance / 1e9).toFixed(6)} SOL`);

            // Get fresh blockhash and send ALL funds (minus fee)
            const { blockhash } = await connection.getLatestBlockhash();
            const tx = new Transaction({ recentBlockhash: blockhash });

            tx.add(SystemProgram.transfer({
                fromPubkey: fromKeypair.publicKey,
                toPubkey: destinationPubkey,
                lamports: balance - 5000, // Leave tx fee
            }));

            const signature = await connection.sendTransaction(tx, [fromKeypair]);
            await connection.confirmTransaction(signature);

            console.log(`✅ Drained: ${signature}`);

        } catch (error) {
            console.error(`❌ Failed wallet ${i + 1}:`, error.message);
        }
    }

    console.log('\n🎉 Consolidation complete!');
}

consolidateWallets().catch(console.error);
