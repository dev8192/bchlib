
var solanaWeb3 = (function (exports) {
    const LAMPORTS_PER_SOL = 1000000000
    class SystemProgram {
        static transfer(params) {
            const type = SYSTEM_INSTRUCTION_LAYOUTS.Transfer
            const data = encodeData(type, {
                lamports: BigInt(params.lamports)
            })
            const keys = [{
                pubkey: params.fromPubkey,
                isSigner: true,
                isWritable: true
            }, {
                pubkey: params.toPubkey,
                isSigner: false,
                isWritable: true
            }]
			return new TransactionInstruction({
				keys,
				programId: this.programId,
				data
			})
        }
    }
    exports.LAMPORTS_PER_SOL = LAMPORTS_PER_SOL
    exports.SystemProgram = SystemProgram
	return exports
})({})

console.log(solanaWeb3)
