
var solanaWeb3 = (function (exports) {
	function encodeData(type, fields) {
		const allocLength = type.layout.span >= 0 ? type.layout.span : getAlloc(type, fields);
		const data = bufferExports.Buffer.alloc(allocLength);
		const layoutFields = Object.assign({
			instruction: type.index
		}, fields);
		type.layout.encode(layoutFields, data);
		return data;
	}
    const LAMPORTS_PER_SOL = 1000000000
    const SYSTEM_INSTRUCTION_LAYOUTS = {
    	Transfer: {
			index: 2,
			layout: LayoutExports.struct([
                LayoutExports.u32('instruction'), 
                u64('lamports')
            ])
		},
    }
    class SystemProgram {
        static transfer(params) {
            const type = SYSTEM_INSTRUCTION_LAYOUTS.Transfer
            const data = encodeData(type, {
                lamports: BigInt(params.lamports)
            })
            const keys = [{
                pubkey: params.fromPubkey,
                isSigner: true,
                isWritable: true
            }, {
                pubkey: params.toPubkey,
                isSigner: false,
                isWritable: true
            }]
			return new TransactionInstruction({
				keys,
				programId: this.programId,
				data
			})
        }
    }
    exports.LAMPORTS_PER_SOL = LAMPORTS_PER_SOL
    exports.SystemProgram = SystemProgram
	return exports
})({})
