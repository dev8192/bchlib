/*
What is the difference between:
(1) solanaWeb3.sendAndConfirmTransaction
(2) connection.sendTransaction() + connection.confirmTransaction()

*/