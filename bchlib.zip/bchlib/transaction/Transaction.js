/*
    Transaction + a bunch of mocks to make it functional
*/

class Transaction {
    get signature() {
        if (this.signatures.length > 0) {
            return this.signatures[0].signature
        }
        return null
    }
    constructor(opts) {
        this.signatures = []
        this.instructions = []
        if (!opts) {
            return
        }
        if (opts.feePayer) {
            this.feePayer = opts.feePayer
        }
        if (opts.signatures) {
            this.signatures = opts.signatures
        }
        if (Object.prototype.hasOwnProperty.call(opts, 'nonceInfo')) {
            const {
                minContextSlot,
                nonceInfo
            } = opts
            this.minNonceContextSlot = minContextSlot
            this.nonceInfo = nonceInfo
        } else if (Object.prototype.hasOwnProperty.call(opts, 'lastValidBlockHeight')) {
            const {
                blockhash,
                lastValidBlockHeight
            } = opts;
            this.recentBlockhash = blockhash;
            this.lastValidBlockHeight = lastValidBlockHeight;
        } else {
            const {
                recentBlockhash,
                nonceInfo
            } = opts;
            if (nonceInfo) {
                this.nonceInfo = nonceInfo;
            }
            this.recentBlockhash = recentBlockhash;
        }
    }
    toJSON() {
        return {
            recentBlockhash: this.recentBlockhash || null,
            feePayer: this.feePayer ? this.feePayer.toJSON() : null,
            nonceInfo: this.nonceInfo ? {
                nonce: this.nonceInfo.nonce,
                nonceInstruction: this.nonceInfo.nonceInstruction.toJSON()
            } : null,
            instructions: this.instructions.map(instruction => instruction.toJSON()),
            signers: this.signatures.map(({ publicKey }) => {
                return publicKey.toJSON();
            })
        };
    }
    add(...items) {
        if (items.length === 0) {
            throw new Error('No instructions');
        }
        items.forEach(item => {
            if ('instructions' in item) {
                this.instructions = this.instructions.concat(item.instructions);
            /*
                This condition is wrong. We need an actual instance of TransactionInstruction.
                If we pass a plain object with these 3 keys, the program will throw,
                e.g. in toJSON()
            */
            } else if ('data' in item && 'programId' in item && 'keys' in item) {
                this.instructions.push(item);
            } else {
                this.instructions.push(new TransactionInstruction(item));
            }
        });
        return this;
    }
    compileMessage() {
        if (this._message && JSON.stringify(this.toJSON()) === JSON.stringify(this._json)) {
            return this._message;
        }
        let recentBlockhash;
        let instructions;
        if (this.nonceInfo) {
            recentBlockhash = this.nonceInfo.nonce;
            if (this.instructions[0] != this.nonceInfo.nonceInstruction) {
                instructions = [this.nonceInfo.nonceInstruction, ...this.instructions];
            } else {
                instructions = this.instructions;
            }
        } else {
            recentBlockhash = this.recentBlockhash;
            instructions = this.instructions;
        }
        if (!recentBlockhash) {
            throw new Error('Transaction recentBlockhash required');
        }
        if (instructions.length < 1) {
            console.warn('No instructions provided');
        }
        let feePayer;
        if (this.feePayer) {
            feePayer = this.feePayer;
        } else if (this.signatures.length > 0 && this.signatures[0].publicKey) {
            feePayer = this.signatures[0].publicKey;
        } else {
            throw new Error('Transaction fee payer required');
        }
        for (let i = 0; i < instructions.length; i++) {
            if (instructions[i].programId === undefined) {
                throw new Error(`Transaction instruction index ${i} has undefined program id`);
            }
        }
        const programIds = [];
        const accountMetas = [];
        instructions.forEach(instruction => {
            instruction.keys.forEach(accountMeta => {
                accountMetas.push({
                    ...accountMeta
                });
            });
            const programId = instruction.programId.toString();
            if (!programIds.includes(programId)) {
                programIds.push(programId);
            }
        });
        programIds.forEach(programId => {
            accountMetas.push({
                pubkey: new PublicKey(programId),
                isSigner: false,
                isWritable: false
            });
        });
        const uniqueMetas = [];
        accountMetas.forEach(accountMeta => {
            const pubkeyString = accountMeta.pubkey.toString();
            const uniqueIndex = uniqueMetas.findIndex(x => {
                return x.pubkey.toString() === pubkeyString;
            });
            if (uniqueIndex > -1) {
                uniqueMetas[uniqueIndex].isWritable = uniqueMetas[uniqueIndex].isWritable || accountMeta.isWritable;
                uniqueMetas[uniqueIndex].isSigner = uniqueMetas[uniqueIndex].isSigner || accountMeta.isSigner;
            } else {
                uniqueMetas.push(accountMeta);
            }
        });
        uniqueMetas.sort(function (x, y) {
            if (x.isSigner !== y.isSigner) {
                return x.isSigner ? -1 : 1;
            }
            if (x.isWritable !== y.isWritable) {
                return x.isWritable ? -1 : 1;
            }
            const options = {
                localeMatcher: 'best fit',
                usage: 'sort',
                sensitivity: 'variant',
                ignorePunctuation: false,
                numeric: false,
                caseFirst: 'lower'
            };
            return x.pubkey.toBase58().localeCompare(y.pubkey.toBase58(), 'en', options);
        });
        const feePayerIndex = uniqueMetas.findIndex(x => {
            return x.pubkey.equals(feePayer);
        });
        if (feePayerIndex > -1) {
            const [payerMeta] = uniqueMetas.splice(feePayerIndex, 1);
            payerMeta.isSigner = true;
            payerMeta.isWritable = true;
            uniqueMetas.unshift(payerMeta);
        } else {
            uniqueMetas.unshift({
                pubkey: feePayer,
                isSigner: true,
                isWritable: true
            });
        }
        for (const signature of this.signatures) {
            const uniqueIndex = uniqueMetas.findIndex(x => {
                return x.pubkey.equals(signature.publicKey);
            });
            if (uniqueIndex > -1) {
                if (!uniqueMetas[uniqueIndex].isSigner) {
                    uniqueMetas[uniqueIndex].isSigner = true;
                    console.warn(
                        'Transaction references a signature that is unnecessary, ' + 
                        'only the fee payer and instruction signer accounts should sign a transaction. ' + 
                        'This behavior is deprecated and will throw an error in the next major version release.'
                    );
                }
            } else {
                throw new Error(`unknown signer: ${signature.publicKey.toString()}`);
            }
        }
        let numRequiredSignatures = 0;
        let numReadonlySignedAccounts = 0;
        let numReadonlyUnsignedAccounts = 0;

        const signedKeys = [];
        const unsignedKeys = [];
        uniqueMetas.forEach(({
            pubkey,
            isSigner,
            isWritable
        }) => {
            if (isSigner) {
                signedKeys.push(pubkey.toString());
                numRequiredSignatures += 1;
                if (!isWritable) {
                    numReadonlySignedAccounts += 1;
                }
            } else {
                unsignedKeys.push(pubkey.toString());
                if (!isWritable) {
                    numReadonlyUnsignedAccounts += 1;
                }
            }
        });
        const accountKeys = signedKeys.concat(unsignedKeys);
        const compiledInstructions = instructions.map(instruction => {
            const {
                data,
                programId
            } = instruction;
            return {
                programIdIndex: accountKeys.indexOf(programId.toString()),
                accounts: instruction.keys.map(meta => accountKeys.indexOf(meta.pubkey.toString())),
                data: bs58.encode(data)
            };
        });
        compiledInstructions.forEach(instruction => {
            assert$1(instruction.programIdIndex >= 0);
            instruction.accounts.forEach(keyIndex => assert$1(keyIndex >= 0));
        });
        return new Message({
            header: {
                numRequiredSignatures,
                numReadonlySignedAccounts,
                numReadonlyUnsignedAccounts
            },
            accountKeys,
            recentBlockhash,
            instructions: compiledInstructions
        });
    }
    _compile() {
        const message = this.compileMessage();
        const signedKeys = message.accountKeys.slice(0, message.header.numRequiredSignatures);
        if (this.signatures.length === signedKeys.length) {
            const valid = this.signatures.every((pair, index) => {
                return signedKeys[index].equals(pair.publicKey);
            });
            if (valid) return message;
        }
        this.signatures = signedKeys.map(publicKey => ({
            signature: null,
            publicKey
        }));
        return message;
    }
    serializeMessage() {
        return this._compile().serialize();
    }
    async getEstimatedFee(connection) {
        return (await connection.getFeeForMessage(this.compileMessage())).value;
    }
    setSigners(...signers) {
        if (signers.length === 0) {
            throw new Error('No signers');
        }
        const seen = new Set();
        this.signatures = signers.filter(publicKey => {
            const key = publicKey.toString();
            if (seen.has(key)) {
                return false;
            } else {
                seen.add(key);
                return true;
            }
        }).map(publicKey => ({
            signature: null,
            publicKey
        }));
    }
    sign(...signers) {
        if (signers.length === 0) {
            throw new Error('No signers');
        }
        const seen = new Set();
        const uniqueSigners = [];
        for (const signer of signers) {
            const key = signer.publicKey.toString();
            if (seen.has(key)) {
                continue;
            } else {
                seen.add(key);
                uniqueSigners.push(signer);
            }
        }
        this.signatures = uniqueSigners.map(signer => ({
            signature: null,
            publicKey: signer.publicKey
        }));
        const message = this._compile();
        this._partialSign(message, ...uniqueSigners);
    }
    partialSign(...signers) {
        if (signers.length === 0) {
            throw new Error('No signers');
        }
        const seen = new Set();
        const uniqueSigners = [];
        for (const signer of signers) {
            const key = signer.publicKey.toString();
            if (seen.has(key)) {
                continue;
            } else {
                seen.add(key);
                uniqueSigners.push(signer);
            }
        }
        const message = this._compile();
        this._partialSign(message, ...uniqueSigners);
    }
    _partialSign(message, ...signers) {
        const signData = message.serialize();
        signers.forEach(signer => {
            const signature = sign(signData, signer.secretKey);
            this._addSignature(signer.publicKey, toBuffer(signature));
        });
    }
    addSignature(pubkey, signature) {
        this._compile();
        this._addSignature(pubkey, signature);
    }
    _addSignature(pubkey, signature) {
        assert$1(signature.length === 64);
        const index = this.signatures.findIndex(sigpair => pubkey.equals(sigpair.publicKey));
        if (index < 0) {
            throw new Error(`unknown signer: ${pubkey.toString()}`);
        }
        this.signatures[index].signature = bufferExports.Buffer.from(signature);
    }
    verifySignatures(requireAllSignatures = true) {
        const signatureErrors = this._getMessageSignednessErrors(this.serializeMessage(), requireAllSignatures);
        return !signatureErrors;
    }
    _getMessageSignednessErrors(message, requireAllSignatures) {
        const errors = {};
        for (const {
            signature,
            publicKey
        } of this.signatures) {
            if (signature === null) {
                if (requireAllSignatures) {
                    (errors.missing ||= []).push(publicKey);
                }
            } else {
                if (!verify(signature, message, publicKey.toBytes())) {
                    (errors.invalid ||= []).push(publicKey);
                }
            }
        }
        return errors.invalid || errors.missing ? errors : undefined;
    }
    serialize(config) {
        const {
            requireAllSignatures,
            verifySignatures
        } = Object.assign({
            requireAllSignatures: true,
            verifySignatures: true
        }, config);
        const signData = this.serializeMessage();
        if (verifySignatures) {
            const sigErrors = this._getMessageSignednessErrors(signData, requireAllSignatures);
            if (sigErrors) {
                let errorMessage = 'Signature verification failed.';
                if (sigErrors.invalid) {
                    errorMessage += `\nInvalid signature for public key${sigErrors.invalid.length === 1 ? '' : '(s)'} [\`${sigErrors.invalid.map(p => p.toBase58()).join('`, `')}\`].`;
                }
                if (sigErrors.missing) {
                    errorMessage += `\nMissing signature for public key${sigErrors.missing.length === 1 ? '' : '(s)'} [\`${sigErrors.missing.map(p => p.toBase58()).join('`, `')}\`].`;
                }
                throw new Error(errorMessage);
            }
        }
        return this._serialize(signData);
    }
    _serialize(signData) {
        const {
            signatures
        } = this;
        const signatureCount = [];
        encodeLength(signatureCount, signatures.length);
        const transactionLength = signatureCount.length + signatures.length * 64 + signData.length;
        const wireTransaction = bufferExports.Buffer.alloc(transactionLength);
        assert$1(signatures.length < 256);
        bufferExports.Buffer.from(signatureCount).copy(wireTransaction, 0);
        signatures.forEach(({
            signature
        }, index) => {
            if (signature !== null) {
                assert$1(signature.length === 64, `signature has invalid length`);
                bufferExports.Buffer.from(signature).copy(wireTransaction, signatureCount.length + index * 64);
            }
        });
        signData.copy(wireTransaction, signatureCount.length + signatures.length * 64);
        assert$1(wireTransaction.length <= PACKET_DATA_SIZE, `Transaction too large: ${wireTransaction.length} > ${PACKET_DATA_SIZE}`);
        return wireTransaction;
    }
    get keys() {
        assert$1(this.instructions.length === 1);
        return this.instructions[0].keys.map(keyObj => keyObj.pubkey);
    }
    get programId() {
        assert$1(this.instructions.length === 1);
        return this.instructions[0].programId;
    }
    get data() {
        assert$1(this.instructions.length === 1);
        return this.instructions[0].data;
    }
    static from(buffer) {
        let byteArray = [...buffer];
        const signatureCount = decodeLength(byteArray);
        let signatures = [];
        for (let i = 0; i < signatureCount; i++) {
            const signature = guardedSplice(byteArray, 0, SIGNATURE_LENGTH_IN_BYTES);
            signatures.push(bs58.encode(bufferExports.Buffer.from(signature)));
        }
        return Transaction.populate(Message.from(byteArray), signatures);
    }
    static populate(message, signatures = []) {
        const transaction = new Transaction();
        transaction.recentBlockhash = message.recentBlockhash;
        if (message.header.numRequiredSignatures > 0) {
            transaction.feePayer = message.accountKeys[0];
        }
        signatures.forEach((signature, index) => {
            const sigPubkeyPair = {
                signature: signature == bs58.encode(DEFAULT_SIGNATURE) ? null : bs58.decode(signature),
                publicKey: message.accountKeys[index]
            };
            transaction.signatures.push(sigPubkeyPair);
        });
        message.instructions.forEach(instruction => {
            const keys = instruction.accounts.map(account => {
                const pubkey = message.accountKeys[account];
                return {
                    pubkey,
                    isSigner: (
                        transaction.signatures.some(keyObj => {
                            return keyObj.publicKey.toString() === pubkey.toString()
                        }) || 
                        message.isAccountSigner(account)
                    ),
                    isWritable: message.isAccountWritable(account)
                };
            });
            transaction.instructions.push(new TransactionInstruction({
                keys,
                programId: message.accountKeys[instruction.programIdIndex],
                data: bs58.decode(instruction.data)
            }));
        });
        transaction._message = message;
        transaction._json = transaction.toJSON();
        return transaction;
    }
}

/****************************** mocks ******************************/

class TransactionInstruction {
    constructor(opts) {
        // this.data = bufferExports.Buffer.alloc(0)
        this.programId = opts.programId
        this.keys = opts.keys
        if (opts.data) {
            this.data = opts.data
        }
    }
    toJSON() {
        return 'hello'
    }
}

function assert$1(condition, message) {
    if (!condition) {
        throw new Error(message || 'Assertion failed')
    }
}

class PublicKey {
    equals() {

    }
}

const bs58 = {
    encode() {
    },
    decode() {
    }
}

class Message {
    constructor(args) {
        this.header = args.header
        this.accountKeys = args.accountKeys.map(account => new PublicKey(account))
    }
}
