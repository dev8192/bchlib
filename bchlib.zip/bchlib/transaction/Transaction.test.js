/*
    This file is basically a set of unit tests for Transaction.
    We test each method of this class in isolation
    to understand its overall mechanics.
*/

function test1() {
    const transaction = new Transaction()
    transaction.add({instructions: [
        new TransactionInstruction({programId: 1}),
        new TransactionInstruction({programId: 2}),
    ]})
    transaction.add({instructions: [
        new TransactionInstruction({programId: 3}),
        new TransactionInstruction({programId: 4}),
    ]})
    transaction.add(new TransactionInstruction({programId: 5}))
    transaction.add({programId: 6})
    console.log(transaction.instructions)
}

function test1() {
    const transaction = new Transaction()
    // transaction.add({data: null, programId: 1, keys: null})
    transaction.add(new TransactionInstruction({programId: 1}))
    console.log(transaction.toJSON())
}

function test1() {
    const transaction = new Transaction()
    transaction.add(new TransactionInstruction({
        programId: 1,
        data: 'data1',
        keys: [{pubkey: 'key1'}],
    }))
    console.log(transaction.programId)
    console.log(transaction.data)
    console.log(transaction.keys)
}

function test1() {
    const transaction = new Transaction({
        recentBlockhash: 333,
        feePayer: 123,
    })
    transaction.add(new TransactionInstruction({
        programId: 123,
        keys: [{pubkey: new PublicKey()}],
    }))
    transaction.compileMessage()
}

function test() {
    const transaction = new Transaction({
        recentBlockhash: 333,
        feePayer: 123,
    })
    transaction.add(new TransactionInstruction({
        programId: 123,
        keys: [{pubkey: new PublicKey()}],
    }))
    const message = transaction._compile()
    console.log(message)
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.serializeMessage()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.sign()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.partialSign()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.addSignature()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

// TODO
function test1() {
    const transaction = new Transaction()
    transaction.func()
}

test()
