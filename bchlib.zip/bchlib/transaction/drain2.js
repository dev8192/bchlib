

async function test() {
    const connection = new solanaWeb3.Connection(
        // solanaWeb3.clusterApiUrl('mainnet-beta'),
        solanaWeb3.clusterApiUrl('devnet'),
        // solanaWeb3.clusterApiUrl('testnet'),
        'confirmed'
    )

    const fromPrivateKey = new Uint8Array([233, 17, 3, 201, 104, 186, 156, 137, 100, 156, 87, 113, 203, 252, 112, 209, 76, 192, 110, 80, 38, 129, 162, 218, 29, 143, 30, 122, 62, 115, 128, 120, 114, 29, 227, 140, 166, 211, 97, 9, 23, 45, 227, 55, 242, 129, 42, 182, 95, 20, 201, 254, 187, 62, 5, 104, 228, 92, 13, 239, 234, 104, 113, 148]);
    const toPublicKey = new solanaWeb3.PublicKey('8W6hLQr2MhaeTnfiNi2BaBiW4zAtT4jLiMuCGLE8GHJu');

    const fromKeypair = solanaWeb3.Keypair.fromSecretKey(fromPrivateKey);
    console.log('From:', fromKeypair.publicKey.toBase58());

    const balance = await connection.getBalance(fromKeypair.publicKey);
    console.log('Balance:', balance);

    if (balance === 0) {
        console.log('No funds to transfer');
        return;
    }

    const blockhash = await connection.getLatestBlockhash();

    const tx = new solanaWeb3.Transaction({ recentBlockhash: blockhash.blockhash });
    tx.add(
        solanaWeb3.SystemProgram.transfer({
            fromPubkey: fromKeypair.publicKey,
            toPubkey: toPublicKey,
            lamports: balance - 5000,
        })
    );

    const sig1 = await connection.sendTransaction(tx, [fromKeypair]);
    await connection.confirmTransaction(sig1);
    console.log('Transfer tx:', sig1);

    const finalBalance = await connection.getBalance(fromKeypair.publicKey);
    console.log('Final balance before close:', finalBalance);

    const toBalance = await connection.getBalance(toPublicKey);
    console.log('Destination new balance:', toBalance);
}

test()
