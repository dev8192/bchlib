/*
give me a js program that sends all money from one solana wallet to another.
I want to move all the money. I dont care about the old account. Nothing should remain in it
*/

async function test(fromKeypair, toPubkey, connection) {
    const balance = await connection.getBalance(fromKeypair.publicKey);
    const rentExempt = 890880 /* min rent-exempt */;
    const transferAmount = Math.max(0, balance - rentExempt - 5000); // Leave tx fee + rent

    if (transferAmount <= 0) {
        console.log('Insufficient balance');
        return;
    }

    const tx = new Transaction().add(
        SystemProgram.transfer({
            fromPubkey: fromKeypair.publicKey,
            toPubkey,
            lamports: transferAmount,
        })
    );

    const signature = await connection.sendTransaction(tx, [fromKeypair]);
    await connection.confirmTransaction(signature);
    console.log(`Sent ${transferAmount / LAMPORTS_PER_SOL} SOL: ${signature}`);
}

test()
