/*
https://explorer.solana.com{signature}?cluster=devnet

*/
async function sendTransaction() {
    try {
        const connection = new solanaWeb3.Connection(
            solanaWeb3.clusterApiUrl('devnet'),
            'confirmed'
        )

        const privKey = 'fff'
        const privKeyArray = JSON.parse(privKey)
        const srcWallet = solanaWeb3.Keypair.fromSecretKey(new Uint8Array(privKeyArray))
        console.log('Sender', srcWallet.publicKey.toString())
        const srcPubkey = srcWallet.publicKey

        const dstAddr = 'fff'
        const dstPubkey = new solanaWeb3.PublicKey(dstAddr)
        const amount = parseFloat(document.getElementById('amount').value)

        const transaction = new solanaWeb3.Transaction()
        transaction.add(
            solanaWeb3.SystemProgram.transfer({
                fromPubkey: srcPubkey,
                toPubkey: dstPubkey,
                lamports: amount * solanaWeb3.LAMPORTS_PER_SOL,
            })
        )

        const signature = await solanaWeb3.sendAndConfirmTransaction(
            connection,
            transaction,
            [srcWallet]
        )

        console.log('signature', signature)
    } catch (err) {
        console.log('error', err)
    }
}

sendTransaction()
