/*
This program sends money from one solana wallet to another
*/
async function test() {
    try {
        const connection = new solanaWeb3.Connection(
            // solanaWeb3.clusterApiUrl('mainnet-beta'),
            solanaWeb3.clusterApiUrl('devnet'),
            // solanaWeb3.clusterApiUrl('testnet'),
            'confirmed'
        )

        const srcWallet = solanaWeb3.Keypair.fromSecretKey(new Uint8Array([233, 17, 3, 201, 104, 186, 156, 137, 100, 156, 87, 113, 203, 252, 112, 209, 76, 192, 110, 80, 38, 129, 162, 218, 29, 143, 30, 122, 62, 115, 128, 120, 114, 29, 227, 140, 166, 211, 97, 9, 23, 45, 227, 55, 242, 129, 42, 182, 95, 20, 201, 254, 187, 62, 5, 104, 228, 92, 13, 239, 234, 104, 113, 148]))
        console.log('Sender', srcWallet.publicKey.toString())
        const srcPubkey = srcWallet.publicKey

        const dstAddr = '4ouPxfGEKyb55dsfNvBNFQKQaBx6x3HsbXACRxRu6VXp'
        const dstPubkey = new solanaWeb3.PublicKey(dstAddr)

        const transaction = new solanaWeb3.Transaction()
        transaction.add(
            solanaWeb3.SystemProgram.transfer({
                fromPubkey: srcPubkey,
                toPubkey: dstPubkey,
                lamports: 1000000,
            })
        )

        const signature = await solanaWeb3.sendAndConfirmTransaction(
            connection,
            transaction,
            [srcWallet]
        )

        console.log('signature', signature)
    } catch (err) {
        console.log('error', err)
    }
}

test()
