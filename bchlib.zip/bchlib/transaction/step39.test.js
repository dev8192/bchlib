
let srcPubkey
let dstPubkey
let amount = 1
solanaWeb3.SystemProgram.transfer({
    fromPubkey: srcPubkey,
    toPubkey: dstPubkey,
    lamports: amount * solanaWeb3.LAMPORTS_PER_SOL,
})

