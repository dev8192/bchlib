
bchlib (Block CHain LIBrary) is a collection of code snippets and components based on the source code of @solana/web3.js.

https://unpkg.com/@solana/web3.js@latest/lib/index.iife.js
https://unpkg.com/@solana/web3.js@1.98.4/lib/index.iife.js

fb96835

