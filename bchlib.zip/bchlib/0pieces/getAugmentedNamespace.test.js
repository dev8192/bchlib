/*

*/

function test() {
    function v4() {
        console.log('hello')
    }
    const esmBrowser = {
        v4: v4,
    }
    const require$$0 = getAugmentedNamespace(esmBrowser)
    require$$0.v4()
}

test()
