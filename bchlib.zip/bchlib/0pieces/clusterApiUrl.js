
const endpoint = {
    http: {
        devnet: 'http://api.devnet.solana.com',
        testnet: 'http://api.testnet.solana.com',
        'mainnet-beta': 'http://api.mainnet-beta.solana.com/'
    },
    https: {
        devnet: 'https://api.devnet.solana.com',
        testnet: 'https://api.testnet.solana.com',
        'mainnet-beta': 'https://api.mainnet-beta.solana.com/'
    }
}

function clusterApiUrl(cluster, tls) {
    const key = tls === false ? 'http' : 'https'
    if (!cluster) {
        return endpoint[key]['devnet']
    }
    const url = endpoint[key][cluster]
    if (!url) {
        throw new Error(`Unknown ${key} cluster: ${cluster}`)
    }
    return url
}

console.log(clusterApiUrl())
console.log(clusterApiUrl(undefined, false))

console.log(clusterApiUrl('devnet'))
console.log(clusterApiUrl('testnet'))
console.log(clusterApiUrl('mainnet-beta'))

console.log(clusterApiUrl('devnet', false))
console.log(clusterApiUrl('testnet', false))
console.log(clusterApiUrl('mainnet-beta', false))


