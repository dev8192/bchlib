

function getDefaultExportFromCjs(x) {
    return (
        x && 
        x.__esModule && 
        Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x
    )
}

console.log(getDefaultExportFromCjs({
    __esModule: true,
    default: 123
}))

console.log(getDefaultExportFromCjs({
    default: 456
}))
