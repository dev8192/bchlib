

const generateKeypair = () => {
    const privateScalar = new Uint8Array(Array.from({length: 32}, () => 11))
    // console.log(privateScalar)
    const publicKey = new Uint8Array(Array.from({length: 32}, () => 22))
    const secretKey = new Uint8Array(64)
    secretKey.set(privateScalar)
    // console.log(secretKey)
    secretKey.set(publicKey, 32)
    // console.log(secretKey)
    return {
        publicKey,
        secretKey
    }
}

const {publicKey, secretKey} = generateKeypair()
console.log(publicKey)
console.log(secretKey)
