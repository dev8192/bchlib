/*
TODO: Get rid of the following errors:
indeterminate span 2
b must be a Uint8Array
*/