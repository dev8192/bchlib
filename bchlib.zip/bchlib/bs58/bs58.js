/*
    <script src="bs58\basex.js"></script>
    <script src="bs58\bs58.js"></script>
*/

var ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
const bs58 = basex(ALPHABET)

function test1() {
    const keypair = solanaWeb3.Keypair.generate()
    
    debugger
    console.log('toBuffer', keypair.publicKey.toBuffer())
    console.log('toBytes', keypair.publicKey.toBytes())
    console.log('toBase58', keypair.publicKey.toBase58())
}

function test() {
    const buf = new Uint8Array([
        0x81, 0x96, 0x40, 0xfd, 0x04, 0x3f, 0x3f, 0x55, 
        0xc2, 0x3a, 0x67, 0x04, 0xae, 0x9c, 0x76, 0x85, 
        0x2a, 0xe0, 0x0b, 0x8a, 0x0d, 0x4e, 0x3f, 0x23, 
        0xfc, 0x01, 0x45, 0xf4, 0x85, 0x9f, 0x25, 0x1d, 
    ])
    const result = bs58.encode(buf)
    console.log(result)
    console.log(result === '9irUjxbZdoN5X7oQtZdh6cDyuTHEHQ3DzRwnKWdAaJFN')
}

test()
