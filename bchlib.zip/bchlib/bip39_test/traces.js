/*

            
generateMnemonic
    entropyToMnemonic
        deriveChecksumBits
            sha256_1


validateMnemonic
    mnemonicToEntropy
        deriveChecksumBits
            sha256_1


mnemonicToSeedSync
    sha512_1
    pbkdf2_1

mnemonicToSeed
    sha512_1
    pbkdf2_1


*/


