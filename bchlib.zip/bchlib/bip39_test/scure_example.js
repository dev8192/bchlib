

async function test() {
    try {
        // 1. Generate a random 12-word mnemonic (128 bits of entropy)
        const mnemonic = ScureBip39.generateMnemonic(ScureBip39.wordlists.english);
        
        // 2. Convert mnemonic to a seed buffer
        const seed = await ScureBip39.mnemonicToSeed(mnemonic);
        const seedHex = Array.from(new Uint8Array(seed))
            .map(b => b.toString(16).padStart(2, '0')).join('');

        // 3. Derive Solana key using the standard path: m/44'/501'/0'/0'
        const derivationPath = "m/44'/501'/0'/0'";
        const derived = ed25519HdKey.derivePath(derivationPath, seedHex);
        
        // 4. Create Solana Keypair from the derived seed
        const keypair = solanaWeb3.Keypair.fromSeed(derived.key);

        // Display results
        document.getElementById('output').textContent = 
            `Mnemonic: ${mnemonic}\n` +
            `Derivation Path: ${derivationPath}\n` +
            `Solana Address: ${keypair.publicKey.toBase58()}`;
    } catch (err) {
        console.error(err);
        alert("Generation failed. Check console for details.");
    }
}

test()
