
const {generateMnemonic} = require("../bip39/index.js");

function test() {
    const mnemonic = generateMnemonic(128)
    console.log(mnemonic)
}

test()
