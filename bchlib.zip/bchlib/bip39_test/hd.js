/*
BIP39 + hierarchical deterministic (HD) derivation (defined in BIP32 and BIP44)

Multi-Chain Recovery Tool

*/
const bip39 = require('bip39');
const { Keypair } = require('@solana/web3.js');
const ed25519HdKey = require('ed25519-hd-key');

const mnemonic = "your 12 or 24 words here";
const seed = bip39.mnemonicToSeedSync(mnemonic);

const path = "m/44'/501'/0'/0'";
const derived = ed25519HdKey.derivePath(path, seed.toString('hex')).key;

// Solana uses first 32 bytes as private key
const keypair = Keypair.fromSeed(derived.slice(0, 32));
console.log("Solana Address:", keypair.publicKey.toBase58());

