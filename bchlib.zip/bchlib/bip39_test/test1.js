/*
    This is a nodejs program
*/

const bip39 = require("../bip39/index.js")
const {sha256} = require("../bip39/sha2.js")

function test1() {
    // const mnemonic = bip39.generateMnemonic(128)
    const mnemonic = 'lend alley seed tissue obey hello fury upon pill fly tattoo almost'
    console.log(mnemonic)
    const seed = bip39.mnemonicToSeedSync(mnemonic)
    console.log(Array.from(seed))
    console.log(seed.length)
}

/*
Why do I need to shorten the seed?
Why do I need to run it through sha256?
*/
function test() {
    const mnemonic = 'lend alley seed tissue obey hello fury upon pill fly tattoo almost'
    const seed = bip39.mnemonicToSeedSync(mnemonic)
    console.log(seed)
    // const secret = sha256(seed.slice(0, 32)).subarray(0, 32)
    // const secret = sha256(seed.slice(0, 32))
    const secret = sha256(seed)
    console.log(secret)
}

test()
