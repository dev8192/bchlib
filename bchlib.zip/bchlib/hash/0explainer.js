/*
What is the point of organizing classes in this way?
*/

function test() {
    class Example1 {
        print() {
            console.log('example1')
        }
    }
    class Example2 {
        print() {
            console.log('example2')
        }
    }
    const obj1 = new Example1()
    obj1.print()
    const obj2 = new Example2()
    obj2.print()
}

function test1() {
    const Example1 = class Hello {
        print() {
            console.log('example1')
        }
    }
    const Example2 = class Hello {
        print() {
            console.log('example2')
        }
    }
    const obj1 = new Example1()
    obj1.print()
    const obj2 = new Example2()
    obj2.print()
}

test()
