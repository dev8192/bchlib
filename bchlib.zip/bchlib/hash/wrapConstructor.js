/*
    What is the point of having two almost identical functions?
*/

const toBytes$1 = () => {}
function wrapConstructor$1(hashCons) { // 2495
    const hashC = (msg) => hashCons().update(toBytes$1(msg)).digest()
    const tmp = hashCons()
    hashC.outputLen = tmp.outputLen
    hashC.blockLen = tmp.blockLen
    hashC.create = () => hashCons()
    return hashC
}

class SHA512 {

}
const sha512 = wrapConstructor$1(() => new SHA512())

function wrapConstructor(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes(msg)).digest()
    const tmp = hashCons()
    hashC.outputLen = tmp.outputLen
    hashC.blockLen = tmp.blockLen
    hashC.create = () => hashCons()
    return hashC
}

let SHA256$1 = class {

}
const sha256$1 = wrapConstructor(() => new SHA256$1())

// const gen = (suffix, blockLen, outputLen) => {
//     return wrapConstructor(() => new Keccak(blockLen, suffix, outputLen))
// }

class SHA256 {
    constructor() {
        console.log('*** constructor ***')
        this.outputLen = 111
        this.blockLen = 222
    }
    update() {
        return this
    }
    digest() {
        return 555
    }
}
// debugger
const sha256 = wrapConstructor$1(() => new SHA256())

// entry point
console.log(sha256)
console.log(sha256.outputLen)
console.log(sha256.blockLen)
console.log(sha256.create().update().digest())
console.log(sha256())
