/*
This program shows how hash funcitons are used in solana

Hash                    2489
[Hash$1]                2489
    HashMD              2544
    [HashMD$1]          2544
        SHA512          2730
        SHA256          23053
    HashMD              8165
        SHA256          8288
        [SHA256$1]      8288

*/

let Hash$1 = class Hash { // 2489
}
let HashMD$1 = class HashMD extends Hash$1 { // 2544
}
class SHA512 extends HashMD$1 { // 2730
}
class SHA256 extends HashMD$1 { // 23053
}
class HashMD extends Hash { // 8165
}
let SHA256$1 = class SHA256 extends HashMD { // 8288
}
