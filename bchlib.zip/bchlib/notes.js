/*
******************** sources of info ********************

https://github.com/solana-foundation/solana-web3.js


https://unpkg.com/@solana/web3.js@latest/lib/index.iife.js
https://unpkg.com/@solana/web3.js@1.98.4/lib/index.iife.js



******************** questions ********************

I want to make transaction inside an html page using
https://unpkg.com/@solana/web3.js@latest/lib/index.iife.js


give me an html page with js that uses
https://unpkg.com/@solana/web3.js@latest/lib/index.iife.js
It must create a wallet and print info about it: its private and public keyes and other things

populate it with money.
I am only interested in js. No need for fancy css



what is the difference between solana devnet and testnet?



Airdrop failed: SolanaJSONRPCError: airdrop failed: Internal error


*/


