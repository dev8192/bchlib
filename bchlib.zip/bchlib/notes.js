/*
******************** sources of info ********************

https://github.com/solana-foundation/solana-web3.js


https://unpkg.com/@solana/web3.js@latest/lib/index.iife.js
https://unpkg.com/@solana/web3.js@1.98.4/lib/index.iife.js


******************** blockchain explorer ********************

https://explorer.solana.com{signature}?cluster=devnet


******************** devnet vs testnet ********************

what is the difference between solana devnet and testnet?


******************** questions ********************

I have multiple solana wallets. I want to join them. give me a js program that does that


*/


