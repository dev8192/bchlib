
function test1() {
    const obj = {
        _isBuffer: true
    }
    console.log(Buffer.isBuffer(obj))
}

function test1() {
    console.log(createBuffer(8))
    console.log(allocUnsafe(8))
    console.log(Buffer.allocUnsafe(8))
    console.log(Buffer.allocUnsafeSlow(8))
    console.log(new Buffer(8))
    console.log(new SlowBuffer(8))
    console.log(from('\0\0\0\0\0\0\0\0'))
    console.log(fromString('\0\0\0\0\0\0\0\0'))
}

function test1() {
    console.log(fromArrayLike([5, 10, 15]))
    console.log(fromArrayView([5, 10, 15]))
    console.log(fromArrayBuffer([5, 10, 15]))
    console.log(fromObject({type: 'Buffer', data: [5, 10, 15]}))
}

function test() {
    class Person {
    }
    const person = new Person()
    class Robot {
    }
    const robot = new Robot()
    console.log(isInstance(person, Person))
    console.log(isInstance(robot, Person))
}

test()
