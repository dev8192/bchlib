/*
This program shows how an RPC request is created
*/
const exampleRequest = {
    "method":"getBalance",
    "jsonrpc":"2.0",
    "params":[
        "8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD",
        {"commitment":"confirmed"}
    ],
    "id":"5aa66030-86c7-4f6e-9dd8-ddcbbb98e191"
}