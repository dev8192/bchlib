/*
    This program shows how error 429 is handled
*/

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

let attempt = 1
async function fetch() {
    console.log('fetch #', attempt++)
    await sleep(500)
    return {status: 429, statusText: 'Too many requests'}
}

async function test() {
    let too_many_requests_retries = 5
    let res
    let waitTime = 500
    for (; ;) {
        res = await fetch()
        too_many_requests_retries -= 1
        if (too_many_requests_retries === 0) {
            break
        }
        console.log(
            `Server responded with ${res.status} ${res.statusText}.` +
            `  Retrying after ${waitTime}ms delay...`
        )
        await sleep(waitTime)
    }
    console.log('done')
}

test()
