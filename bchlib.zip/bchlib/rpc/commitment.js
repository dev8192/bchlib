/*
What is the difference between finalized and confirmed commitment in solana?
*/