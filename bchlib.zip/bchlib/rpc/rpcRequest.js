/*
This program shows how an RPC request is done
*/

async function fetchImpl(url, options) {
    console.log(url)
    console.log(options.body)
    return {
        async text() {
            return JSON.stringify({
                hello: 'world'
            })
        }
    }
}

function generateRequest() {
    
}

const ClientBrowser = function (callServer) {
    this.callServer = callServer
}
ClientBrowser.prototype.request = function (method, params, id, callback) {
    const self = this
    callback = id
    const request = generateRequest(method)
    const message = JSON.stringify(request)
    this.callServer(message, function (err, response) {
        self._parseResponse(err, response, callback);
    })
}
ClientBrowser.prototype._parseResponse = function (err, responseText, callback) {
    const response = JSON.parse(responseText)
    callback(null, response)
}

const RpcClient = ClientBrowser

function createRpcClient(
    url,
    httpHeaders,
    customFetch,
    fetchMiddleware,
    disableRetryOnRateLimit,
    httpAgent
) {
    const fetch = customFetch ? customFetch : fetchImpl
    const clientBrowser = new RpcClient(async (request, callback) => {
        const options = {
            body: request,
        }
        const res = await fetch(url, options)
        const text = await res.text()
        callback(null, text)
    })
    return clientBrowser
}

function createRpcRequest(client) {
    return (method, args) => {
        return new Promise((resolve, reject) => {
            client.request(method, args, (err, response) => {
                if (err) {
                    reject(err)
                    return
                }
                resolve(response)
            })
        })
    }
}

// entry point
const endpoint = 'http://example.com'
const rpcClient = createRpcClient(endpoint)
const rpcRequest = createRpcRequest(rpcClient)
const res = rpcRequest('getBalance').then((res) => {
    console.log(res)
})
