


class Message {
    constructor(args) {
        this.header = void 0;
        this.accountKeys = void 0;
        this.recentBlockhash = void 0;
        this.instructions = void 0;
        this.indexToProgramIds = new Map();
        this.header = args.header;
        this.accountKeys = args.accountKeys.map(account => new PublicKey(account));
        this.recentBlockhash = args.recentBlockhash;
        this.instructions = args.instructions;
        this.instructions.forEach(ix => this.indexToProgramIds.set(ix.programIdIndex, this.accountKeys[ix.programIdIndex]));
    }
    get version() {
        return 'legacy';
    }
    get staticAccountKeys() {
        return this.accountKeys;
    }
    get compiledInstructions() {
        return this.instructions.map(ix => ({
            programIdIndex: ix.programIdIndex,
            accountKeyIndexes: ix.accounts,
            data: bs58.decode(ix.data)
        }));
    }
    get addressTableLookups() {
        return [];
    }
    getAccountKeys() {
        return new MessageAccountKeys(this.staticAccountKeys);
    }
    static compile(args) {
        const compiledKeys = CompiledKeys.compile(args.instructions, args.payerKey);
        const [header, staticAccountKeys] = compiledKeys.getMessageComponents();
        const accountKeys = new MessageAccountKeys(staticAccountKeys);
        const instructions = accountKeys.compileInstructions(args.instructions).map(ix => ({
            programIdIndex: ix.programIdIndex,
            accounts: ix.accountKeyIndexes,
            data: bs58.encode(ix.data)
        }));
        return new Message({
            header,
            accountKeys: staticAccountKeys,
            recentBlockhash: args.recentBlockhash,
            instructions
        });
    }
    isAccountSigner(index) {
        return index < this.header.numRequiredSignatures;
    }
    isAccountWritable(index) {
        const numSignedAccounts = this.header.numRequiredSignatures;
        if (index >= this.header.numRequiredSignatures) {
            const unsignedAccountIndex = index - numSignedAccounts;
            const numUnsignedAccounts = this.accountKeys.length - numSignedAccounts;
            const numWritableUnsignedAccounts = numUnsignedAccounts - this.header.numReadonlyUnsignedAccounts;
            return unsignedAccountIndex < numWritableUnsignedAccounts;
        } else {
            const numWritableSignedAccounts = numSignedAccounts - this.header.numReadonlySignedAccounts;
            return index < numWritableSignedAccounts;
        }
    }
    isProgramId(index) {
        return this.indexToProgramIds.has(index);
    }
    programIds() {
        return [...this.indexToProgramIds.values()];
    }
    nonProgramIds() {
        return this.accountKeys.filter((_, index) => !this.isProgramId(index));
    }
    serialize() {
        const numKeys = this.accountKeys.length;
        let keyCount = [];
        encodeLength(keyCount, numKeys);
        const instructions = this.instructions.map(instruction => {
            const {
                accounts,
                programIdIndex
            } = instruction;
            const data = Array.from(bs58.decode(instruction.data));
            let keyIndicesCount = [];
            encodeLength(keyIndicesCount, accounts.length);
            let dataCount = [];
            encodeLength(dataCount, data.length);
            return {
                programIdIndex,
                keyIndicesCount: bufferExports.Buffer.from(keyIndicesCount),
                keyIndices: accounts,
                dataLength: bufferExports.Buffer.from(dataCount),
                data
            };
        });
        let instructionCount = [];
        encodeLength(instructionCount, instructions.length);
        let instructionBuffer = bufferExports.Buffer.alloc(PACKET_DATA_SIZE);
        bufferExports.Buffer.from(instructionCount).copy(instructionBuffer);
        let instructionBufferLength = instructionCount.length;
        instructions.forEach(instruction => {
            const instructionLayout = LayoutExports.struct([LayoutExports.u8('programIdIndex'), LayoutExports.blob(instruction.keyIndicesCount.length, 'keyIndicesCount'), LayoutExports.seq(LayoutExports.u8('keyIndex'), instruction.keyIndices.length, 'keyIndices'), LayoutExports.blob(instruction.dataLength.length, 'dataLength'), LayoutExports.seq(LayoutExports.u8('userdatum'), instruction.data.length, 'data')]);
            const length = instructionLayout.encode(instruction, instructionBuffer, instructionBufferLength);
            instructionBufferLength += length;
        });
        instructionBuffer = instructionBuffer.slice(0, instructionBufferLength);
        const signDataLayout = LayoutExports.struct([LayoutExports.blob(1, 'numRequiredSignatures'), LayoutExports.blob(1, 'numReadonlySignedAccounts'), LayoutExports.blob(1, 'numReadonlyUnsignedAccounts'), LayoutExports.blob(keyCount.length, 'keyCount'), LayoutExports.seq(publicKey('key'), numKeys, 'keys'), publicKey('recentBlockhash')]);
        const transaction = {
            numRequiredSignatures: bufferExports.Buffer.from([this.header.numRequiredSignatures]),
            numReadonlySignedAccounts: bufferExports.Buffer.from([this.header.numReadonlySignedAccounts]),
            numReadonlyUnsignedAccounts: bufferExports.Buffer.from([this.header.numReadonlyUnsignedAccounts]),
            keyCount: bufferExports.Buffer.from(keyCount),
            keys: this.accountKeys.map(key => toBuffer(key.toBytes())),
            recentBlockhash: bs58.decode(this.recentBlockhash)
        };
        let signData = bufferExports.Buffer.alloc(2048);
        const length = signDataLayout.encode(transaction, signData);
        instructionBuffer.copy(signData, length);
        return signData.slice(0, length + instructionBuffer.length);
    }
    static from(buffer) {
        let byteArray = [...buffer];
        const numRequiredSignatures = guardedShift(byteArray);
        if (numRequiredSignatures !== (numRequiredSignatures & VERSION_PREFIX_MASK)) {
            throw new Error('Versioned messages must be deserialized with VersionedMessage.deserialize()');
        }
        const numReadonlySignedAccounts = guardedShift(byteArray);
        const numReadonlyUnsignedAccounts = guardedShift(byteArray);
        const accountCount = decodeLength(byteArray);
        let accountKeys = [];
        for (let i = 0; i < accountCount; i++) {
            const account = guardedSplice(byteArray, 0, PUBLIC_KEY_LENGTH);
            accountKeys.push(new PublicKey(bufferExports.Buffer.from(account)));
        }
        const recentBlockhash = guardedSplice(byteArray, 0, PUBLIC_KEY_LENGTH);
        const instructionCount = decodeLength(byteArray);
        let instructions = [];
        for (let i = 0; i < instructionCount; i++) {
            const programIdIndex = guardedShift(byteArray);
            const accountCount = decodeLength(byteArray);
            const accounts = guardedSplice(byteArray, 0, accountCount);
            const dataLength = decodeLength(byteArray);
            const dataSlice = guardedSplice(byteArray, 0, dataLength);
            const data = bs58.encode(bufferExports.Buffer.from(dataSlice));
            instructions.push({
                programIdIndex,
                accounts,
                data
            });
        }
        const messageArgs = {
            header: {
                numRequiredSignatures,
                numReadonlySignedAccounts,
                numReadonlyUnsignedAccounts
            },
            recentBlockhash: bs58.encode(bufferExports.Buffer.from(recentBlockhash)),
            accountKeys,
            instructions
        };
        return new Message(messageArgs);
    }
}
