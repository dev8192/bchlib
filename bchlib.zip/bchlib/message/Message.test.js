/*
    Basic example
*/
function test() {
    const message = new Message({
        accountKeys: [],
        instructions: [],
    })
    console.log(message)
}

/*
    A more practical example
*/
function test1() {
    const message = new Message({
        header: {
            numRequiredSignatures,
            numReadonlySignedAccounts,
            numReadonlyUnsignedAccounts
        },
        accountKeys,
        recentBlockhash,
        instructions: compiledInstructions
    })
    console.log(message)
}

test()
