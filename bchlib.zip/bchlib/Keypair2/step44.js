
var solanaWeb3 = (function (exports) {
	const generateKeypair = () => {
        const publicKey = 111
        const secretKey = 222
        return {
            publicKey,
            secretKey
        }
	}
    class Keypair {
        constructor(keypair) {
            this._keypair = keypair
        }
        static generate() {
            return new Keypair(generateKeypair())
        }
    }
    exports.Keypair = Keypair
    return exports
})
({});
