/*
8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD
[233, 17, 3, 201, 104, 186, 156, 137, 100, 156, 87, 113, 203, 252, 112, 209, 76, 192, 110, 80, 38, 129, 162, 218, 29, 143, 30, 122, 62, 115, 128, 120, 114, 29, 227, 140, 166, 211, 97, 9, 23, 45, 227, 55, 242, 129, 42, 182, 95, 20, 201, 254, 187, 62, 5, 104, 228, 92, 13, 239, 234, 104, 113, 148]

*/
function test1() {
    const keypair = solanaWeb3.Keypair.generate()
    console.log(keypair)
}

function test() {
    const keypair = solanaWeb3.Keypair.generate()
    const publicKey = keypair.publicKey.toString()
    console.log(publicKey)
    const secretKey = Array.from(keypair.secretKey)
    console.log(secretKey)
}
test()
