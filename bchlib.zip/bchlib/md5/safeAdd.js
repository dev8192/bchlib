
function safeAdd(x, y) {
    var lsw = (x & 0xffff) + (y & 0xffff)
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16)
    const result = msw << 16 | lsw & 0xffff
    return result
}

/*
560296549 718787259 1279083808
-1078558230 -2074806642 1141602424
207453737 -235173006 -27719269
0 1126891415 1126891415
0 -421815835 -421815835
undefined 530742520 530742520
*/

;(function() {
    '0x' + (718787259).toString(16).padStart(8, '0')
    (0x0000ffff << 16).toString(16) // -10000
    (0xffff0000).toString(16) // ffff0000
    (0xffff0000 | 0).toString(16) // -10000
    (0x0000ffff >> 16).toString(16) // 0
    (0x0000ffff >> 12).toString(16) // f

    (0x100000000 >> 1).toString(16) // 0
    (0x10000000 >> 1).toString(16) // 8000000
    (0x7fff0000 >> 16).toString(16) // 7fff
    (0xffff0000 >>> 16).toString(16) // ffff
    (0xffff0000 >> 16).toString(16) // -1
});

function test() {
    console.log(safeAdd(0x21657265, 0x2ad7d2bb))
}

test()
