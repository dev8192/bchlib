
function test() {
    const digest = md5('hello')
    console.log(digest)
}

test()
