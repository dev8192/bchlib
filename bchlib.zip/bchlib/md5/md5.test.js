/*
    <script src="0util\convertHex2.js"></script>
    <script src="md5\md5.js"></script>
    <script src="md5\md5.test.js"></script>

    SubtleCrypto does not support MD-5
*/

function test1() {
    const digest = md5('hello there!')
    console.log(digest)
    console.log(toString(digest))
    console.log(toString(digest) === '8f199aebac0036c0c1fa2304eecc3d54')
}

test()
