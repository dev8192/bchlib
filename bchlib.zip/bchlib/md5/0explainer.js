
function test() {
    console.log(escape('hello world'))
    console.log(unescape('hello%20world'))
    console.log(encodeURIComponent('hello world'))
    console.log(decodeURIComponent('hello%20world'))
}

test()
