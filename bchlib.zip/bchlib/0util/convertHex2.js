
function toString(arr) {
    let result = ''
    for(let i = 0; i < arr.length; i++){
        result += arr[i].toString(16).padStart(2, '0')
    }
    return result
}

function toArray(str) {
    const result = []
    for(let i = 0; i < str.length; i += 2){
        result.push(Number('0x' + str.substring(i, i + 2)))
    }
    return result
}
