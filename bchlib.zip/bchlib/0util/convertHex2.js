
function bytesToString(bytes) {
    let result = ''
    for(let i = 0; i < bytes.length; i++){
        result += bytes[i].toString(16).padStart(2, '0')
    }
    return result
}

function bytesToString2(bytes) {
    return Array.from(bytes).map(byte => {
        return byte.toString(16).padStart(2, '0')
    }).join('')
}

function stringToBytes(str) {
    const result = []
    for(let i = 0; i < str.length; i += 2){
        result.push(Number('0x' + str.substring(i, i + 2)))
    }
    return result
}
