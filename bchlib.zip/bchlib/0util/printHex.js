function printHex(arr) {
    const result = []
    const upperBound = arr.length / 8
    for (let i = 0; i < upperBound; i++) {
        const row = []
        for (let j = 0; j < 8; j++) {
            row.push('0x' + arr[i * 8 + j].toString(16).padStart(2, '0') + ', ')
        }
        result.push(row.join(''))
        row.length = 0
    }
    return result.join('\n')
}

const arr = [
    79, 3, 99, 196, 75, 203, 27, 161, 98, 212, 122, 68, 161, 112, 36, 136, 148, 137, 145, 45, 54, 133, 218, 22, 211, 128, 239, 37, 156, 56, 127, 105, 38, 162, 167, 209, 53, 179, 116, 243, 85, 65, 50, 155, 115, 204, 53, 242, 73, 2, 35, 95, 107, 175, 200, 120, 226, 104, 210, 246, 236, 186, 219, 2,
]
console.log(printHex(arr))

function parseHex(str) {
    const result = []
    for (let row of str.split('\n')) {
        row = row.split(', ').slice(0, -1)
        for (const item of row) {
            result.push(Number(item))
        }
    }
    return result
}

const str = `0x26, 0xa2, 0xa7, 0xd1, 0x35, 0xb3, 0x74, 0xf3, 
0x55, 0x41, 0x32, 0x9b, 0x73, 0xcc, 0x35, 0xf2, 
0x49, 0x02, 0x23, 0x5f, 0x6b, 0xaf, 0xc8, 0x78, 
0xe2, 0x68, 0xd2, 0xf6, 0xec, 0xba, 0xdb, 0x02, `
const arr2 = parseHex(str)
// console.log(arr2)

function compareArrays(arr1, arr2) {
    if (arr1.length !== arr2.length) {
        return false
    }
    for (let i = 0; i < arr1.length; i++) {
        if (arr1[i] !== arr2[i]) {
            return false
        }
    }
    return true
}

// console.log(compareArrays(arr, arr2))
