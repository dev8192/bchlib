
function toHexString(arr) {
    const result = []
    const upperBound = arr.length / 8
    for (let i = 0; i < upperBound; i++) {
        const row = []
        for (let j = 0; j < 8; j++) {
            row.push('0x' + arr[i * 8 + j].toString(16).padStart(2, '0') + ', ')
        }
        result.push(row.join(''))
        row.length = 0
    }
    return result.join('\n')
}

function parseHexString(str) {
    const result = []
    for (let row of str.split('\n')) {
        row = row.split(', ').slice(0, -1)
        for (const item of row) {
            result.push(Number(item))
        }
    }
    return result
}
