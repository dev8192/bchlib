/*
    <script src="0util\compareArrays.js"></script>
    <script src="0util\convertHex.js"></script>
    <script src="0util\convertHex.test.js"></script>
*/
const arr1 = [
    79, 3, 99, 196, 75, 203, 27, 161, 98, 212, 122, 68, 161, 112, 36, 136,
    148, 137, 145, 45, 54, 133, 218, 22, 211, 128, 239, 37, 156, 56, 127, 105,
    38, 162, 167, 209, 53, 179, 116, 243, 85, 65, 50, 155, 115, 204, 53, 242,
    73, 2, 35, 95, 107, 175, 200, 120, 226, 104, 210, 246, 236, 186, 219, 2,
]
const str1 = `0x4f, 0x03, 0x63, 0xc4, 0x4b, 0xcb, 0x1b, 0xa1, 
0x62, 0xd4, 0x7a, 0x44, 0xa1, 0x70, 0x24, 0x88, 
0x94, 0x89, 0x91, 0x2d, 0x36, 0x85, 0xda, 0x16, 
0xd3, 0x80, 0xef, 0x25, 0x9c, 0x38, 0x7f, 0x69, 
0x26, 0xa2, 0xa7, 0xd1, 0x35, 0xb3, 0x74, 0xf3, 
0x55, 0x41, 0x32, 0x9b, 0x73, 0xcc, 0x35, 0xf2, 
0x49, 0x02, 0x23, 0x5f, 0x6b, 0xaf, 0xc8, 0x78, 
0xe2, 0x68, 0xd2, 0xf6, 0xec, 0xba, 0xdb, 0x02, `

function test1() {
    const str2 = toHexString(arr1)
    console.log(str1)
    console.log(str2)
    console.log(str1 === str2)
}

function test1() {
    const arr2 = parseHexString(str1)
    console.log(arr1)
    console.log(arr2)
    console.log(compareArrays(arr1, arr2))
}

function test1() {
    const arr2 = parseHexString(toHexString(arr1))
    console.log(arr1)
    console.log(arr2)
    console.log(compareArrays(arr1, arr2))
}

function test() {
    const str2 = toHexString(parseHexString(str1))
    console.log(str1)
    console.log(str2)
    console.log(str1 === str2)
}

test()
