/*
    <script src="0util\compareArrays.js"></script>
    <script src="0util\convertHex2.js"></script>
    <script src="0util\convertHex2.test.js"></script>
*/
function test1() {
    const arr = [
        143, 25, 154, 235, 172, 0, 54, 192,
        193, 250, 35, 4, 238, 204, 61, 84,
    ]
    console.log(arr)
    console.log(toString(arr))
}

function test1() {
    const str = '8f199aebac0036c0c1fa2304eecc3d54'
    console.log(str)
    console.log(toArray(str))
}

function test1() {
    const str1 = '8f199aebac0036c0c1fa2304eecc3d54'
    const str2 = toString(toArray(str1))
    console.log(str1)
    console.log(str2)
    console.log(str1 === str2)
}

function test() {
    const arr1 = [
        143, 25, 154, 235, 172, 0, 54, 192,
        193, 250, 35, 4, 238, 204, 61, 84,
    ]
    const arr2 = toArray(toString(arr1))
    console.log(arr1)
    console.log(arr2)
    console.log(compareArrays(arr1, arr2))
}

test()
