/*
    atob - ascii to binary
    btoa - binary to ascii

    <script src="0util\compareArrays.js"></script>
    <script src="base64\0explainer.js"></script>
*/

const binary1 = [
    0x81, 0x96, 0x40, 0xfd, 0x04, 0x3f, 0x3f, 0x55, 
    0xc2, 0x3a, 0x67, 0x04, 0xae, 0x9c, 0x76, 0x85, 
    0x2a, 0xe0, 0x0b, 0x8a, 0x0d, 0x4e, 0x3f, 0x23, 
    0xfc, 0x01, 0x45, 0xf4, 0x85, 0x9f, 0x25, 0x1d, 
].map(byte => String.fromCharCode(byte)).join('')
const ascii1 = 'MTI5LDE1MCw2NCwyNTMsNCw2Myw2Myw4NSwxOTQsNTgsMTAzLDQsMTc0LDE1NiwxMTgsMTMzLDQyLDIyNCwxMSwxMzgsMTMsNzgsNjMsMzUsMjUyLDEsNjksMjQ0LDEzMywxNTksMzcsMjk='


function test1() {
    const ascii2 = btoa(binary1)
    console.log(ascii2)
    const binary2 = atob(ascii2)
    console.log(compareArrays(binary1, binary2))
}

function test() {
    const binary2 = atob(ascii1)
    console.log(binary1)
    console.log(binary2)
    const ascii2 = btoa(binary2)
    console.log(ascii1)
    console.log(ascii2)
    console.log(ascii1 === ascii2)
}

test()
