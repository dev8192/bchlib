/*
    An alternative way to convert an array of bytes to base64

    <script src="bs58\basex.js"></script>
    <script src="base64\step30.js"></script>
*/

const bytes = [
    0x81, 0x96, 0x40, 0xfd, 0x04, 0x3f, 0x3f, 0x55, 
    0xc2, 0x3a, 0x67, 0x04, 0xae, 0x9c, 0x76, 0x85, 
    0x2a, 0xe0, 0x0b, 0x8a, 0x0d, 0x4e, 0x3f, 0x23, 
    0xfc, 0x01, 0x45, 0xf4, 0x85, 0x9f, 0x25, 0x1d, 
]

function convert1(bytes) {
    const binStr = bytes.map(byte => String.fromCharCode(byte)).join('')
    return btoa(binStr)
}

function convert2(bytes) {
    const arr = new Uint8Array(bytes)
    return arr.toBase64()    
}

function convert3(bytes) {
    var ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    const base64 = basex(ALPHABET)
    return base64.encode(bytes)
}

const str1 = convert1(bytes)
const str2 = convert2(bytes)
const str3 = convert2(bytes)
console.log(str1)
console.log(str2)
console.log(str3)
console.log(str1 === str2)
console.log(str2 === str3)
