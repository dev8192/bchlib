/*
    A traditional way to convert to/from base64
    
    atob - ascii to binary
    btoa - binary to ascii
*/

function test1() {
    const binary1 = 'Hello, world!'
    const ascii1 = 'SGVsbG8sIHdvcmxkIQ=='

    const ascii2 = btoa(binary1)
    console.log(ascii1)
    console.log(ascii2)
    console.log(ascii1 === ascii2)

    const binary2 = atob(ascii2)
    console.log(binary1)
    console.log(binary2)
    console.log(binary1 === binary2)
}

function test() {
    const binary1 = 'Hello, world!'
    const ascii1 = 'SGVsbG8sIHdvcmxkIQ=='

    const binary2 = atob(ascii1)
    console.log(binary1)
    console.log(binary2)
    console.log(binary1 === binary2)

    const ascii2 = btoa(binary2)
    console.log(ascii1)
    console.log(ascii2)
    console.log(ascii1 === ascii2)
}

test()
