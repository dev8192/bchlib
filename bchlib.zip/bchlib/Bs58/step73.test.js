

const keypair = solanaWeb3.Keypair.generate()

console.log('toBytes', keypair.publicKey.toBytes())
console.log('toBuffer', keypair.publicKey.toBuffer())
console.log('toBase58', keypair.publicKey.toBase58())
