/*
    <script src="0util\convertHex2.js"></script>
    <script src="sha1\sha1.js"></script>
    <script src="sha1\sha1.test.js"></script>
*/

const message = 'hello'
const digest = 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'

async function test() {
    console.log('subtle crypto')
    const encoder = new TextEncoder()
    const data = encoder.encode(message)
    const hashBuffer = await crypto.subtle.digest('SHA-1', data)
    const hashArray = new Uint8Array(hashBuffer)
    console.log(hashArray)
    console.log(bytesToString(hashArray))
    console.log(bytesToString(hashArray) === digest)
}

function test1() {
    console.log('custom')
    const hashArray = sha1(message)
    console.log(hashArray)
    console.log(bytesToString(hashArray))
    console.log(bytesToString(hashArray) === digest)
}

test()
