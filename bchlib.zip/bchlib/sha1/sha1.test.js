/*
    <script src="0util\convertHex2.js"></script>
    <script src="sha1\sha1.js"></script>
    <script src="sha1\sha1.test.js"></script>
*/

function test() {
    const digest = sha1('hello there!')
    console.log(digest)
    console.log(toString(digest))
    console.log(toString(digest) === 'fff')
}

test()
