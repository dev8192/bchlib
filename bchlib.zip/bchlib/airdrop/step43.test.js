/*
    Request airdrop with retry
*/
async function test() {
    try {
        const WALLET_PUBLIC_KEY = '2nr1bHFT86W9tGnyvmYW4vcHKsQB3sVQfnddasz4kExM'
        const NETWORK = "devnet";
        // const NETWORK = "testnet";
        const publicKey = new solanaWeb3.PublicKey(WALLET_PUBLIC_KEY)
        const connection = new solanaWeb3.Connection(
            // 'https://api.testnet.solana.com', 
            solanaWeb3.clusterApiUrl(NETWORK),
            'confirmed'
        )
        const signature = await connection.requestAirdrop(
            publicKey, 
            solanaWeb3.LAMPORTS_PER_SOL
        )
        // await connection.confirmTransaction(signature)
        await connection.confirmTransaction({
            blockhash: latestBlockHash.blockhash,
            lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
            signature
        })
    } catch (error) {
        console.error("Airdrop failed:")
        console.log(error)
    }
}

test()
