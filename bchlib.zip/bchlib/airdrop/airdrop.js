
const WALLET_PUBLIC_KEY = "8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD"

// Choose network: 'devnet' or 'testnet'
const NETWORK = "devnet" // or "testnet"

async function requestAirdrop() {
    try {
        const publicKey = new solanaWeb3.PublicKey(WALLET_PUBLIC_KEY)
        
        const connection = new solanaWeb3.Connection(
            solanaWeb3.clusterApiUrl(NETWORK),
            'confirmed'
        )

        const signature = await connection.requestAirdrop(
            publicKey,
            solanaWeb3.LAMPORTS_PER_SOL
        )

        console.log("Airdrop transaction signature:", signature)

        await connection.confirmTransaction(signature)
        console.log("Airdrop confirmed! Check your balance.")

        console.log('done')
    } catch (error) {
        console.error("Airdrop failed:", error)
    }
}

requestAirdrop()
