
const WALLET_PUBLIC_KEY = "8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD";
const NETWORK = "devnet";
// const NETWORK = "testnet";

async function requestAirdropWithRetry() {
    try {
        const publicKey = new solanaWeb3.PublicKey(WALLET_PUBLIC_KEY);
        const connection = new solanaWeb3.Connection(
            solanaWeb3.clusterApiUrl(NETWORK),
            'confirmed'
        );
        console.log(`Requesting 1 SOL on ${NETWORK} for:`, publicKey.toString());

        const signature = await connection.requestAirdrop(
            publicKey,
            solanaWeb3.LAMPORTS_PER_SOL
        );

        console.log("✅ Airdrop requested! Signature:", signature);

        const latestBlockHash = await connection.getLatestBlockhash();
        await connection.confirmTransaction({
            blockhash: latestBlockHash.blockhash,
            lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
            signature
        });

        console.log("Airdrop confirmed!")
    } catch (error) {
        console.error("Airdrop failed:")
        console.log(error)
    }
}

requestAirdropWithRetry()
