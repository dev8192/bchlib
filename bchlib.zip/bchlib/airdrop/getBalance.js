// Replace with your wallet address
const WALLET_ADDRESS = "8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD";

// Connect to Solana mainnet
const connection = new solanaWeb3.Connection(
    solanaWeb3.clusterApiUrl('mainnet-beta'),
    'confirmed'
);

// Get balance function
async function getBalance() {
    try {
        const publicKey = new solanaWeb3.PublicKey(WALLET_ADDRESS);
        const balanceLamports = await connection.getBalance(publicKey);
        const balanceSOL = balanceLamports / solanaWeb3.LAMPORTS_PER_SOL;
        
        console.log("=== SOLANA BALANCE ===");
        console.log("Address:", WALLET_ADDRESS);
        console.log("Balance:", balanceSOL, "SOL");
        console.log("======================");
        
        // Display on page
        document.body.innerHTML = `
            <h2>Solana Wallet Balance</h2>
            <p><strong>Address:</strong> ${WALLET_ADDRESS}</p>
            <p><strong>Balance:</strong> ${balanceSOL} SOL</p>
        `;
    } catch (error) {
        console.error("Error fetching balance:", error);
        document.body.innerHTML = `
            <h2>Error</h2>
            <p>Failed to fetch balance. Check console for details.</p>
            <p>Common issues:</p>
            <ul>
                <li>Invalid wallet address</li>
                <li>No internet connection</li>
                <li>RPC rate limit</li>
            </ul>
        `;
    }
}

// Execute when page loads
getBalance();
