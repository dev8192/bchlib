/*
    <script src="0util\compareArrays.js"></script>
    <script src="base64Js\base64Js.js"></script>
    <script src="base64Js\base64Js.test.js"></script>
*/

const bytes = [
    0x81, 0x96, 0x40, 0xfd, 0x04, 0x3f, 0x3f, 0x55, 
    0xc2, 0x3a, 0x67, 0x04, 0xae, 0x9c, 0x76, 0x85, 
    0x2a, 0xe0, 0x0b, 0x8a, 0x0d, 0x4e, 0x3f, 0x23, 
    0xfc, 0x01, 0x45, 0xf4, 0x85, 0x9f, 0x25, 0x1d, 
]
const str = 'gZZA/QQ/P1XCOmcErpx2hSrgC4oNTj8j/AFF9IWfJR0='

function test() {
    // debugger
    const str1 = fromByteArray(bytes)
    console.log(str1)
    const str2 = btoa(bytes.map(byte => String.fromCharCode(byte)).join(''))
    console.log(str2)
    console.log(str1 === str2)
}

function test1() {
    const bytes1 = toByteArray(str)
    console.log(bytes1)
    const bytes2 = atob(str).split('').map(ch => ch.charCodeAt())
    console.log(bytes2)
    console.log(compareArrays(bytes1, bytes2))
}

test()
