
function test(buf, value, offset, littleEndian) {
    ieee754.write(buf, value, offset, littleEndian, 23, 4)
}

function test(buf, value, offset, littleEndian) {
    ieee754.write(buf, value, offset, littleEndian, 52, 8)
}

// readFloatLE
function test() {
    ieee754.read({
        buffer: [],
        offset: 0,
        isLE: true,
        mLen: 23,
        nBytes: 4,
    })
}

// readFloatBE
function test() {
    ieee754.read({
        buffer: [],
        offset: 0,
        isLE: false,
        mLen: 23,
        nBytes: 4,
    })
}

// readDoubleLE
function test() {
    ieee754.read({
        buffer: [],
        offset: 0,
        isLE: true,
        mLen: 52,
        nBytes: 8,
    })
}

// readDoubleBE
function test() {
    ieee754.read({
        buffer: [],
        offset: 0,
        isLE: false,
        mLen: 52,
        nBytes: 8,
    })
}

test()
