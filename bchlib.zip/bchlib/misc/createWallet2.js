


async function requestAirdropWithRetry({connection, publicKey, lamports, maxRetries}) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            console.log(`Attempt ${i + 1}/${maxRetries}: Requesting airdrop...`)
            const signature = await connection.requestAirdrop(publicKey, lamports)
            console.log(`Airdrop requested! Signature: ${signature.substring(0, 8)}...`)    
            const { value } = await connection.confirmTransaction(signature, 'confirmed')
            if (value?.err) {
                throw new Error(`Transaction failed: ${JSON.stringify(value.err)}`)
            }
            console.log(`Airdrop confirmed!`)
            return true
        } catch (error) {
            console.log(`Attempt ${i + 1} failed`, error)
            if (i === maxRetries - 1) {
                throw new Error(`All ${maxRetries} attempts failed.`)
            }
            await new Promise(resolve => setTimeout(resolve, 2000 * (i + 1)))
        }
    }
}

async function createWalletAndFund() {
    try {
        const keypair = solanaWeb3.Keypair.generate()
        const publicKey = keypair.publicKey.toBase58()
        console.log(publicKey)
        const secretKey = Array.from(keypair.secretKey)
        console.log('Secret Key', secretKey.join(', '))
        
        debugger
        const connection = new solanaWeb3.Connection(
            solanaWeb3.clusterApiUrl('devnet'),
            { commitment: 'confirmed', timeout: 30000 }
        )

        console.log(connection)

        return

        const initialBalance = await connection.getBalance(keypair.publicKey)
        if (initialBalance > 0) {
            console.log('Final Balance', (initialBalance / solanaWeb3.LAMPORTS_PER_SOL).toFixed(2))
        } else {
            await requestAirdropWithRetry({
                connection,
                publicKey: keypair.publicKey,
                lamports: 1_000_000_000, // 1 SOL
                maxRetries: 5,
            })
        }

        const finalBalance = await connection.getBalance(keypair.publicKey)
        console.log('Final Balance', (finalBalance / solanaWeb3.LAMPORTS_PER_SOL).toFixed(2))
    } catch (error) {
        console.error("Full error:", error)
    }
}

createWalletAndFund()
