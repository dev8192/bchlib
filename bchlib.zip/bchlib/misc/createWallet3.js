// Generate a new keypair
const keypair = solanaWeb3.Keypair.generate();
const publicKey = keypair.publicKey.toBase58();
const secretKey = Array.from(keypair.secretKey);
const publicKeyBytes = Array.from(keypair.publicKey.toBytes());

// Prepare wallet info
const info = {
    "Public Key (Base58)": publicKey,
    "Public Key (Bytes)": publicKeyBytes,
    "Private Key (Secret Key)": secretKey,
    "Private Key Length": secretKey.length + " bytes",
    "Network": "This key works on Devnet, Testnet, and Mainnet (but NEVER share it!)",
    "Warning": "⚠️ THIS IS FOR TESTING ONLY. Never use this key for real funds unless you save it securely."
};
