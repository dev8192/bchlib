/*
    Generate a new keypair
*/

const keypair = solanaWeb3.Keypair.generate()

const publicKey = keypair.publicKey.toBase58()
console.log("Public Key", publicKey)

const secretKey = Array.from(keypair.secretKey)
console.log("Private Key Length", secretKey.length + " bytes")

const publicKeyBytes = Array.from(keypair.publicKey.toBytes())
console.log("Public Key (Bytes)", publicKeyBytes)

console.log("Private Key (Secret Key)", secretKey)
