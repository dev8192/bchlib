/*
'exports' is treated specially when using the F2 function
to rename a symbol
*/
function example1(exports) {
    exports.num1 = 111
    exports.num2 = 222
    return exports
}

function example2(aaa) {
    aaa.num1 = 111
    aaa.num2 = 222
    return aaa
}
