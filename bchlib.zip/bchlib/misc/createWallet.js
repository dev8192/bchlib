/*
    Create a new keypair (wallet)
*/

async function createWalletAndFund() {
    try {
        const keypair = solanaWeb3.Keypair.generate()
        const publicKey = keypair.publicKey.toBase58()
        const secretKey = Array.from(keypair.secretKey)

        console.log('Public Key', publicKey)

        const connection = new solanaWeb3.Connection(
            solanaWeb3.clusterApiUrl('devnet'),
            'confirmed'
        )

        const airdropSignature = await connection.requestAirdrop(
            keypair.publicKey,
            2_000_000_000 // 2 SOL
        )

        console.log('Airdrop requested')
        await connection.confirmTransaction(airdropSignature)

        const balance = await connection.getBalance(keypair.publicKey)
        console.log('balance', (balance / solanaWeb3.LAMPORTS_PER_SOL).toFixed(2))
        console.log('Public Key', publicKey)
        console.log('Secret Key', secretKey.join(', '))

    } catch (error) {
        console.log(error)
    }
}

createWalletAndFund()
