
var solanaWeb3 = (function (exports) {
    class Transaction {
        add() {
            console.log('add')
        }
    }
    exports.Transaction = Transaction
	return exports
})({});

const transaction = new solanaWeb3.Transaction()
transaction.add()
