
function modExp(base, exp, modulus) {
    let result = 1n
    base = BigInt(base) % BigInt(modulus)
    exp = BigInt(exp)
    modulus = BigInt(modulus)

    while (exp > 0n) {
        if (exp % 2n === 1n) {
            result = (result * base) % modulus
        }
        exp = exp >> 1n
        base = (base * base) % modulus
    }
    return Number(result)
}
