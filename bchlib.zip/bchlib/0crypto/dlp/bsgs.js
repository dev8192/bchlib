/**
 * Computes modular exponentiation (base^exp % mod) efficiently.
 */
function power(base, exp, mod) {
    let res = 1n;
    base = base % mod;
    while (exp > 0n) {
        if (exp % 2n === 1n) res = (res * base) % mod;
        base = (base * base) % mod;
        exp = exp / 2n;
    }
    return res;
}

/**
 * Computes the discrete logarithm x such that (a^x % m) == b
 * Returns -1 if no solution is found.
 */
function discreteLogarithm(a, b, m) {
    a = BigInt(a);
    b = BigInt(b);
    m = BigInt(m);

    // n = ceil(sqrt(m))
    let n = BigInt(Math.ceil(Math.sqrt(Number(m))));

    // Baby-step: Store precomputed values of a^j % m in a Map
    let babySteps = new Map();
    for (let j = 0n; j < n; j++) {
        babySteps.set(power(a, j, m), j);
    }

    // Giant-step precomputation: a^(-n) % m
    // Using Fermat's Little Theorem: a^(m-2) % m is the inverse if m is prime
    let factor = power(a, n * (m - 2n), m);

    let current = b;
    for (let i = 0n; i < n; i++) {
        // Check if current giant step matches any baby step
        if (babySteps.has(current)) {
            let j = babySteps.get(current);
            return i * n + j;
        }
        // Multiply by a^(-n) to take the next giant step
        current = (current * factor) % m;
    }

    return -1;
}

// Example usage: 2^x ≡ 3 (mod 5) -> x should be 3
const a = 2, b = 3, m = 5;
const result = discreteLogarithm(a, b, m);

console.log(`The discrete log of ${b} base ${a} modulo ${m} is: ${result}`);
// Verification: 2^3 = 8; 8 % 5 = 3.
