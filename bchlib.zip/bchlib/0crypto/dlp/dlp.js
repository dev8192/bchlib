/*
DLP (discrete logarithm problem)

2^5 = 32
log2(32) = 5    logarithm base 2 of 32 is 5

5^a ≡ 8 mod 23 → find a

g^x ≡ h mod p


give me a js program (no html, css and fancy formatting) that demonstrates how to compute discrete logarithm


*/

