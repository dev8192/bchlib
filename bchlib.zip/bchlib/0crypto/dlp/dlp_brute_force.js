// Discrete logarithm demo: solve for x in a^x ≡ y (mod p)
// This uses a simple brute-force search, suitable only for small p.

function modPow(base, exponent, modulus) {
    if (modulus === 1) return 0;
    let result = 1n;
    let b = BigInt(base) % BigInt(modulus);
    let e = BigInt(exponent);
    const m = BigInt(modulus);

    while (e > 0n) {
        if (e & 1n) {
            result = (result * b) % m;
        }
        b = (b * b) % m;
        e >>= 1n;
    }
    return result;
}

// Brute-force discrete log: find smallest x >= 0 such that a^x ≡ y (mod p)
function discreteLogBruteForce(a, y, p) {
    const A = BigInt(a);
    const Y = BigInt(y);
    const P = BigInt(p);

    let value = 1n;
    for (let x = 0n; x < P; x++) {
        if (value === Y) {
            return x; // found solution
        }
        value = (value * A) % P;
    }
    return null; // no solution
}

// Example usage:
// Solve 2^x ≡ 5 (mod 13)
const a = 2n;
const y = 5n;
const p = 13n;

const x = discreteLogBruteForce(a, y, p);

if (x !== null) {
    console.log(`Solution: ${a}^${x} ≡ ${y} (mod ${p})`);
} else {
    console.log("No solution found");
}
