
// Modular exponentiation: base^exp mod mod
function modpow(base, exp, mod) {
    let result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 === 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exp = Math.floor(exp / 2);
    }
    return result;
}

// Baby-step giant-step discrete log: find x where g^x ≡ h (mod p)
// p prime, g primitive root mod p. Time/space O(sqrt(p)).
function discreteLog(g, h, p) {
    if (h === 1) return 0;
    const m = Math.ceil(Math.sqrt(p - 1));
    const baby = new Map();

    // Baby steps: g^j mod p for j=0 to m-1
    let curr = 1;
    for (let j = 0; j < m; j++) {
        baby.set(curr, j);
        curr = (curr * g) % p;
    }

    // Giant step: g^{-m} mod p using Fermat (g^{p-2} = g^{-1})
    const gInv = modpow(g, p - 2, p);
    let giantStep = 1;
    for (let i = 0; i < m; i++) {
        giantStep = (giantStep * gInv) % p;
    }

    // Check giant steps: h * (g^{-m})^i mod p
    curr = h % p;
    for (let i = 0; i < m; i++) {
        if (baby.has(curr)) {
            return (i * m + baby.get(curr)) % (p - 1);
        }
        curr = (curr * giantStep) % p;
    }
    return -1; // No solution
}

// Demo examples
console.log('2^x ≡ 3 (mod 5): x=', discreteLog(2, 3, 5)); // 4, since 2^4=16≡1 mod5 wait no: 2^1=2,2^2=4,2^3=3,2^4=1 so 3
console.log('Expected 3');
console.log('3^x ≡ 7 (mod 11): x=', discreteLog(3, 7, 11)); // Check: 3^1=3,3^2=9,3^3=5,3^4=4,3^5=1, wait adjust
console.log('5^x ≡ 5 (mod 19): x=', discreteLog(5, 5, 19)); // 1
