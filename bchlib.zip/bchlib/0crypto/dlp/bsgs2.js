// Baby-step Giant-step discrete logarithm demo
// Solve a^x ≡ y (mod p) for x
// Works for reasonably small p (e.g., up to ~10^9 depending on memory)

function modPow(base, exp, mod) {
    base = BigInt(base) % BigInt(mod);
    exp = BigInt(exp);
    mod = BigInt(mod);
    let result = 1n;

    while (exp > 0n) {
        if (exp & 1n) result = (result * base) % mod;
        base = (base * base) % mod;
        exp >>= 1n;
    }
    return result;
}

function discreteLog(a, y, p) {
    a = BigInt(a);
    y = BigInt(y);
    p = BigInt(p);

    const m = BigInt(Math.ceil(Math.sqrt(Number(p))));

    const table = new Map();
    let value = 1n;

    // Baby steps: store a^j
    for (let j = 0n; j < m; j++) {
        table.set(value, j);
        value = (value * a) % p;
    }

    // Compute a^-m
    const factor = modPow(a, p - 1n - m, p);

    let gamma = y;

    // Giant steps
    for (let i = 0n; i < m; i++) {
        if (table.has(gamma)) {
            return i * m + table.get(gamma);
        }
        gamma = (gamma * factor) % p;
    }

    return null;
}

// Example: solve 2^x ≡ 5 (mod 13)
const a = 2n;
const y = 5n;
const p = 13n;

const x = discreteLog(a, y, p);

if (x !== null) {
    console.log(`x = ${x}`);
} else {
    console.log("No solution");
}
