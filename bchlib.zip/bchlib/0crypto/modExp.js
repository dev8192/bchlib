/*
    modular exponentiation (base^exp mod modulus)
*/
