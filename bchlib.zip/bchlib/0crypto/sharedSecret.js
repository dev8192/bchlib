/*
    Diffie-Hellman Key Exchange

    <script src="0crypto\modExp_BigInt.js"></script>
    <script src="0crypto\sharedSecret.js"></script>
*/

const p = 23
console.log('Prime modulus', p)
const g = 5
console.log('Base (primitive root mod p)', g)

const alicePrivate = 6
console.log('alicePrivate', alicePrivate)
const alicePublic = modExp(g, alicePrivate, p)
console.log('g^a mod p', alicePublic)

const bobPrivate = 15
console.log('bobPrivate', bobPrivate)
const bobPublic = modExp(g, bobPrivate, p)
console.log('g^b mod p', bobPublic)

const aliceShared = modExp(bobPublic, alicePrivate, p)
console.log('B^a mod p', aliceShared)
const bobShared = modExp(alicePublic, bobPrivate, p)
console.log('A^b mod p', bobShared)

console.log(aliceShared === bobShared)
