/*
The first 64 bits of the fractional parts
of the square roots of the first eight prime numbers
(RFC6234)
Newton's method for accurate integer square roots

tell me about Newton's method for square roots

When I do Math.sqrt(2) in js, I get 1.4142135623730951. But it is not enough precision for me. I need much more. How do i use Math.sqrt() with BigInt?
*/
function isqrt(n) {
    if (n < 0n) throw new Error('Input must be non-negative');
    if (n < 2n) return n;
    let x = n;
    let y = (x + 1n) >> 1n;
    while (y < x) {
        x = y;
        y = (x + n / x) >> 1n;
    }
    console.log(n, x)
    return x;
}

const primes = [2, 3, 5, 7, 11, 13, 17, 19];
const two64 = 2n ** 64n;
const two128 = two64 * two64;

const result = []
for (let i = 0; i < primes.length; i++) {
    const p = BigInt(primes[i]);
    const k = isqrt(p);
    const N = p * two128; // p * 2^128
    const root = isqrt(N); // floor(sqrt(p) * 2^64)
    const fractional = root - k * two64; // Scaled fractional part (64 bits)
    result.push(fractional)
}

const expectedResult = [
    0x6a09e667f3bcc908n,
    0xbb67ae8584caa73bn,
    0x3c6ef372fe94f82bn,
    0xa54ff53a5f1d36f1n,
    0x510e527fade682d1n,
    0x9b05688c2b3e6c1fn,
    0x1f83d9abfb41bd6bn,
    0x5be0cd19137e2179n,
]
function test() {
    for (let i = 0; i < expectedResult.length; i++) {
        if (result[i] !== expectedResult[i]) {
            console.log(result[i].toString(16))
            console.log(expectedResult[i].toString(16))
            return
        }
    }
    console.log('done')
}
test()
