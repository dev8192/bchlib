/*
    L - the message length
    K - the number of 0's that must be appended to a message
    (L + 1 + K) mod 512 = 448     RFC6234 4.1     SHA-224 and SHA-256
    (L + 1 + K) mod 1024 = 896    RFC6234 4.2     SHA-384 and SHA-512

    How to solve the equation:
    (L + 1 + K) mod 512 = 448
    K mod 512 = (448 - (L + 1)) mod 512

    (a - b) mod m = (a mod m - b mod m) mod m

are these 2 equivalent or not?
((448 - (L + 1)) % 512 + 512) % 512
(448 - (L + 1) % 512 + 512) % 512
if they are, i want a clear step by step explantion how one turns into another
with references to the laws of mathematics.
without skipping any steps. no mathy bullshit. keep it simple so that a child can understand
*/
function equation() {
    ((448 - (L + 1)) % 512 + 512) % 512         // start
    (448 % 512 - ((L + 1) % 512) + 512) % 512
    ((448 - (L + 1) % 512) % 512 + 512) % 512
    (448 - (L + 1) % 512 + 512) % 512           // end
}

function calculateK(L, blockSize) {
    const mod = ((448 - (L + 1)) % 512 + 512) % 512
    return mod
    let temp = (L + 1) % 512
    return (448 - temp + 512) % 512
}

function test() {
    const blockSize = 512
    // const blockSize = 1024

    // const L = 447 // 0
    const L = 448 // 511
    const K = calculateK(L, blockSize)
    console.log(K)
    console.log(( L + 1 + K ) % 512 === 448)
}

test()
