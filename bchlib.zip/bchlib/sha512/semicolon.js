
/*
    Based on the split() function
    Uncaught ReferenceError: Cannot access 'h' before initialization
*/
function test1() {
    let arr1 = []
    let arr2 = []
    const temp = {h: 111, l: 222}
    console.log(temp)
    const { h, l } = temp; // missing semicolon here causes the error
    [arr1[0], arr2[0]] = [h, l]
}

/*
    There is a better solution - don't use pythonisms in JS
*/
function test() {
    let arr1 = []
    let arr2 = []
    const temp = {h: 111, l: 222}
    console.log(temp)
    const { h, l } = temp
    arr1[0] = h
    arr2[0] = l
}

test()

