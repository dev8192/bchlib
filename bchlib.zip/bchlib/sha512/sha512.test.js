/*
    <script src="0util\convertHex2.js"></script>
    <script src="sha512\sha512.js"></script>
    <script src="sha512\sha512.test.js"></script>
*/

const message = 'hello'
const digest = '9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043'

async function check(message, digest) {
    const encoder = new TextEncoder()
    const data = encoder.encode(message)
    const hashBuffer = await crypto.subtle.digest('SHA-512', data)
    const hashArray = new Uint8Array(hashBuffer)
    console.log(hashArray)
    console.log(bytesToString(hashArray))
    console.log(bytesToString(hashArray) === digest)
}

function test() {
    // debugger
    // const data = new Uint8Array(new TextEncoder().encode(message))
    // const data = new Uint8Array(message.split('').map(ch => ch.charCodeAt()))
    // const data = [104, 101, 108, 108, 111]
    const data = new Uint8Array([104, 101, 108, 108, 111])
    const hashArray = sha512(data)
    check(message, bytesToString(hashArray))
}

function test1() {
    console.log('input.length is 128 bytes')
    // debugger
    const message = 'a'.repeat(128)
    const hashArray = sha512(message)
    check(message, bytesToString(hashArray))
}

function test1() {
    const crypto = require('node:crypto')
    const str = crypto.hash('sha512', message)
    console.log(str)
}

test()
