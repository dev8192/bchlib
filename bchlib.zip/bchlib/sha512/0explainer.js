
function test() {
    console.log(0x428a2f98d728ae22n.toString(16))
    console.log(BigInt('0x428a2f98d728ae22').toString(16))
}

function test() {
    const add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0)
}

test()
