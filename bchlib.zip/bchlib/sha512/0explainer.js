
function test1() {
    console.log(0x428a2f98d728ae22n.toString(16))
    console.log(BigInt('0x428a2f98d728ae22').toString(16))
}

function test1() {
    const add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0)
}

function test1() {
    const num1 = 0x428a2f98d728ae22n
    const num2 = 1116352408n
    const num3 = 3609767458n
    console.log((num1 >> 32n) === num2)
    console.log((num1 & 0xFFFFFFFFn) === num3)
}

test()
