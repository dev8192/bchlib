

/*
001fffff ffffffff
*/
function test1() {
    // console.log((0xffffffffffffffff).toString(16)) // 64 bit
    // console.log((0xffffffffffffffff - 1).toString(16))
    console.log(Number.MAX_SAFE_INTEGER.toString(16))
}

/*
    TODO: two's complement
*/
function test1() {
    const num1 = 0xf3bcc908         // 4089235720
    const num2 = 0xf3bcc908 | 0     // -205731576
    console.log(num1)
    console.log(num2)
}

/*
0xf     1111
0x7     0111
*/
function test() {
    const num1 = 0x73bcc908         // 4089235720
    const num2 = 0x73bcc908 | 0     // -205731576
    console.log(num1)
    console.log(num2)
}

test()
