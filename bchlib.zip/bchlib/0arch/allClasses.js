/*

All classes and constructor functions


EventEmitter
    WebSocketBrowserImpl
    CommonClient
        RpcWebSocketClient

Error
    DERErr
    BorshError
    TransactionExpiredBlockheightExceededError
    TransactionExpiredTimeoutError
    TransactionExpiredNonceInvalidError
    SendTransactionError
    SolanaJSONRPCError
    SolanaError
    TypeError               (builtin)
        StructError

Layout$1
    ExternalLayout
        GreedyCount
        OffsetLayout
    UInt            UIntBE
    Int             IntBE
    NearUInt64      NearUInt64BE
    NearInt64       NearInt64BE
    Float           FloatBE
    Double          DoubleBE
    Sequence
    Structure
    Union
    VariantLayout
    BitStructure
    Blob
    CString
    UTF8
    Constant

Struct$1
    Enum
    PublicKey

BitField
    Boolean

UnionDiscriminator
    UnionLayoutDiscriminator

Hash                    2489
[Hash$1]                2489
    HashMD              2544
    [HashMD$1]          2544
        SHA512          2730
        SHA256          23053
    HashMD              8165
        SHA256          8288
        [SHA256$1]      8288
    Keccak              22909
    HMAC                23135


*/