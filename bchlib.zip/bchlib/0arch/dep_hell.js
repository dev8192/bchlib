/*


@solana/web3.js
    @babel/runtime                  zerodep
    @noble/curves
    @noble/hashes                   zd
    @solana/buffer-layout
        buffer
            base64-js
            ieee754
    @solana/codecs-numbers
        @solana/codecs-core
        @solana/errors
    agentkeepalive
        humanize-ms
    bn.js
    borsh
    bs58
        base-x
    buffer
    fast-stable-stringify
    jayson
        @types/connect
        @types/node
        @types/ws
        commander
        delay
        es6-promisify
        eyes
        isomorphic-ws
        json-stringify-safe
        stream-json
        uuid
        ws
    node-fetch
        data-uri-to-buffer
        fetch-blob
        formdata-polyfill
    rpc-websockets
        @swc/helpers
        @types/uuid
        @types/ws
        buffer
        eventemitter3
        uuid
        ws
    superstruct

    SafeBuffer
    Src
    Bs58
    Encoding_lib
    Lib
    Layout
    FastStableStringify
    GenerateRequest
    Browser

@noble/curves
    @noble/hashes           zd
bip39
    @noble/hashes
ed25519-hd-key
    tweetnacl
    create-hmac
        cipher-base
            inherits
            safe-buffer
            to-buffer
        create-hash
            cipher-base
            inherits
            md5.js
            ripemd160
            sha.js
        inherits
        ripemd160
            hash-base
            inherits
        safe-buffer
        sha.js
            inherits
            safe-buffer
            to-buffer
                isarray
                safe-buffer
                typed-array-buffer



i want to create a key pair with ed25519-hd-key
the problem is it has a garbage dependency - create-hmac,
which in turn has a million of other dependencies.
this is abnormal because this is a relatively simple task.
what are my options?


micro-ed25519-hdkey         deprecated
micro-key-producer          create-hmac-like monstrosity
ed25519-keygen

*/