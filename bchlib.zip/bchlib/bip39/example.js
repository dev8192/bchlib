/*

unpkg bip39
https://github.com/bitcoinjs/bip39


*/
const bip39 = require('bip39');
const { Keypair } = require('@solana/web3.js');
const { sha256 } = require('@noble/hashes/sha256');

const mnemonic = bip39.generateMnemonic(128); // 128 bits = 12 words
console.log(mnemonic);

const seed = bip39.mnemonicToSeedSync(mnemonic);

const secret = sha256(seed.slice(0, 32)).subarray(0, 32);

const keypair = Keypair.fromSeed(secret);
console.log('Public Key:', keypair.publicKey.toBase58());
