const responses = [
    {
        "data": {
            "type": "Buffer",
            "data": []
        },
        "executable": false,
        "lamports": 1000000000,
        "owner": "11111111111111111111111111111111",
        "rentEpoch": 18446744073709552000,
        "space": 0
    }
]
async function test() {
    const connection = new solanaWeb3.Connection(
        // solanaWeb3.clusterApiUrl("mainnet-beta"),
        solanaWeb3.clusterApiUrl("devnet"),
        // solanaWeb3.clusterApiUrl("testnet"),
        "confirmed"
    );
    const publicKey = new solanaWeb3.PublicKey("8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD");
    const accountInfo = await connection.getAccountInfo(publicKey);
    
    console.log(JSON.stringify(accountInfo, null, 4));
}

test()
