
const responses = [
    {'feature-set': 2086771155, 'solana-core': '3.1.6'},
]

async function test() {
    const connection = new solanaWeb3.Connection(
        solanaWeb3.clusterApiUrl("devnet"),
        "confirmed"
    )
    const version = await connection.getVersion()
    console.log(version)
}

test()
