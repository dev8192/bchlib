/*
TODO: I can send RPC requests on devnet and testnet via a simple html page.
It does not work with mainnet because
the 'Access-Control-Allow-Origin' header contains the invalid value 'backend_traffic'.
Is there a workaround?

*/