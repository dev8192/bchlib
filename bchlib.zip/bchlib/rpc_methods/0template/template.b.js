

async function test() {
    const connection = new solanaWeb3.Connection(
        solanaWeb3.clusterApiUrl('mainnet-beta'),
        // solanaWeb3.clusterApiUrl('devnet'),
        // solanaWeb3.clusterApiUrl('testnet'),
        'confirmed'
    )
    // let commitment = 'processed'
    let commitment = 'confirmed'
    // let commitment = 'finalized'
    let latestBlockhash = await connection.getLatestBlockhash(commitment)
    console.log(latestBlockhash)
}

test()
