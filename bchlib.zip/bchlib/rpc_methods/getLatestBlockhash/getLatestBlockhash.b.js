/*
This program shows the difference between different types of commitment in solana

When i do getLatestBlockhash(), it seems to take the same amount of type 

The 'Access-Control-Allow-Origin' header contains the invalid value 'backend_traffic'
*/

const responses = [
    {blockhash: '5CDXBUwEjFHwC48qMym4Es47EsyRqqK8rmwgwGRGpQPX', lastValidBlockHeight: 425232625},
    {blockhash: '3qjjECTQMpfTPRgKJaeCHnDEcoc6QRwmTrst2tghJ9JT', lastValidBlockHeight: 425232757},
]

async function test() {
    const connection = new solanaWeb3.Connection(
        solanaWeb3.clusterApiUrl("mainnet-beta"),
        // solanaWeb3.clusterApiUrl("devnet"),
        // solanaWeb3.clusterApiUrl("testnet"),
        "confirmed"
    )
    // let commitment = "processed"
    let commitment = "confirmed"
    // let commitment = "finalized"
    let latestBlockhash = await connection.getLatestBlockhash(commitment)
    console.log(latestBlockhash)
}

async function test1() {
    const connection = new solanaWeb3.Connection(
        solanaWeb3.clusterApiUrl("devnet"),
        "confirmed"
    )
    const commitment = [
        "processed",
        "confirmed",
        "finalized",
    ]
    for (const item of commitment) {
        let latestBlockhash = await connection.getLatestBlockhash(item)
        console.log(latestBlockhash)
    }
}

function test1() {
    const connection = new solanaWeb3.Connection(
        solanaWeb3.clusterApiUrl("mainnet-beta"),
        // solanaWeb3.clusterApiUrl("devnet"),
        // solanaWeb3.clusterApiUrl("testnet"),
        "finalized"
    )
    setInterval(async () => {
        // let commitment = "processed"
        // let commitment = "confirmed"
        let commitment = "finalized"
        let latestBlockhash = await connection.getLatestBlockhash(commitment)
        console.log(latestBlockhash)
    }, 1000)
}

test()
