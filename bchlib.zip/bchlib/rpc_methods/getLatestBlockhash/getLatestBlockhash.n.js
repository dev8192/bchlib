/*
give me a nodejs program that performs getLatestBlockhash().
don't use libraries. pure nodejs please

*/

async function getLatestBlockhash() {
    const rpcUrl = 'https://api.mainnet-beta.solana.com';
    // const rpcUrl = 'https://api.devnet.solana.com';
    // const rpcUrl = 'https://api.testnet.solana.com';
    const requestBody = {
        jsonrpc: '2.0',
        id: 1,
        method: 'getLatestBlockhash',
        // params: [{ commitment: 'processed' }],
        // params: [{ commitment: 'confirmed' }],
        params: [{ commitment: 'finalized' }],
    };

    try {
        const response = await fetch(rpcUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        if (data.error) {
            throw new Error(`RPC Error: ${data.error.message}`);
        }

        console.log(data)
    } catch (error) {
        console.error('Error:', error.message);
    }
}

getLatestBlockhash();
