


let Struct$1 = class Struct {
    constructor(properties) {
        Object.assign(this, properties);
    }
    encode() {
        return bufferExports.Buffer.from(libExports.serialize(SOLANA_SCHEMA, this));
    }
    static decode(data) {
        return libExports.deserialize(SOLANA_SCHEMA, this, data);
    }
    static decodeUnchecked(data) {
        return libExports.deserializeUnchecked(SOLANA_SCHEMA, this, data);
    }
}

let uniquePublicKeyCounter = 1

class PublicKey extends Struct$1 {
    constructor(value) {
        super({});
        if (isPublicKeyData(value)) {
            this._bn = value._bn;
        } else {
            if (typeof value === 'string') {
                const decoded = bs58.decode(value);
                if (decoded.length != PUBLIC_KEY_LENGTH) {
                    throw new Error(`Invalid public key input`);
                }
                this._bn = new BN(decoded);
            } else {
                this._bn = new BN(value);
            }
            if (this._bn.byteLength() > PUBLIC_KEY_LENGTH) {
                throw new Error(`Invalid public key input`);
            }
        }
    }
    static unique() {
        const key = new PublicKey(uniquePublicKeyCounter);
        uniquePublicKeyCounter += 1;
        return new PublicKey(key.toBuffer());
    }
    equals(publicKey) {
        return this._bn.eq(publicKey._bn);
    }
    toBase58() {
        return bs58.encode(this.toBytes());
    }
    toJSON() {
        return this.toBase58();
    }
    toBytes() {
        const buf = this.toBuffer();
        return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
    }
    toBuffer() {
        const b = this._bn.toArrayLike(bufferExports.Buffer);
        if (b.length === PUBLIC_KEY_LENGTH) {
            return b;
        }
        const zeroPad = bufferExports.Buffer.alloc(32);
        b.copy(zeroPad, 32 - b.length);
        return zeroPad;
    }
    get [Symbol.toStringTag]() {
        return `PublicKey(${this.toString()})`;
    }
    toString() {
        return this.toBase58();
    }
    static async createWithSeed(fromPublicKey, seed, programId) {
        const buffer = bufferExports.Buffer.concat([fromPublicKey.toBuffer(), bufferExports.Buffer.from(seed), programId.toBuffer()]);
        const publicKeyBytes = sha256$1(buffer);
        return new PublicKey(publicKeyBytes);
    }
    static createProgramAddressSync(seeds, programId) {
        let buffer = bufferExports.Buffer.alloc(0);
        seeds.forEach(function (seed) {
            if (seed.length > MAX_SEED_LENGTH) {
                throw new TypeError(`Max seed length exceeded`);
            }
            buffer = bufferExports.Buffer.concat([buffer, toBuffer(seed)]);
        });
        buffer = bufferExports.Buffer.concat([buffer, programId.toBuffer(), bufferExports.Buffer.from('ProgramDerivedAddress')]);
        const publicKeyBytes = sha256$1(buffer);
        if (isOnCurve(publicKeyBytes)) {
            throw new Error(`Invalid seeds, address must fall off the curve`);
        }
        return new PublicKey(publicKeyBytes);
    }
    static async createProgramAddress(seeds, programId) {
        return this.createProgramAddressSync(seeds, programId);
    }
    static findProgramAddressSync(seeds, programId) {
        let nonce = 255;
        let address;
        while (nonce != 0) {
            try {
                const seedsWithNonce = seeds.concat(bufferExports.Buffer.from([nonce]));
                address = this.createProgramAddressSync(seedsWithNonce, programId);
            } catch (err) {
                if (err instanceof TypeError) {
                    throw err;
                }
                nonce--;
                continue;
            }
            return [address, nonce];
        }
        throw new Error(`Unable to find a viable program address nonce`);
    }
    static async findProgramAddress(seeds, programId) {
        return this.findProgramAddressSync(seeds, programId);
    }
    static isOnCurve(pubkeyData) {
        const pubkey = new PublicKey(pubkeyData);
        return isOnCurve(pubkey.toBytes());
    }
}
