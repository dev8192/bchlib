/*
    BigInt playground
*/

function test1() {
    console.log(BigInt(1) << BigInt(0))
    console.log(BigInt(1) << BigInt(1))
    console.log(BigInt(1) << BigInt(2))
    console.log(BigInt(1) << BigInt(3))
    console.log(BigInt(1) << BigInt(4))
}

function test1() {
    const num1 = BigInt(1) << BigInt(4)
    console.log(num1.toString(2))
}

/*
 15112221349535400772501151409588531511454012693041857206046113283949847762202      Gx
 46316835694926478169428394003475163141307993866256225615783033603165251855960      Gy
 57896044618658097711785492504343953926634992332820282019728792003956564819949      ED25519_P (ORDER)
115792089237316195423570985008687907853269984665640564039457584007913129639936      MASK

10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
*/
function test1() {
    const _1n = BigInt(1)
    const _2n = BigInt(2)

    const nByteLength = 32
    const MASK = _2n << (BigInt(nByteLength * 8) - _1n)
    console.log(MASK)
    console.log(MASK.toString(2))
}

/*
7fffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffed     ED25519_P
ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f     secp256k1
*/
function test1() {
    const ED25519_P = BigInt('57896044618658097711785492504343953926634992332820282019728792003956564819949')
    const num1 = 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn
    const num2 = BigInt(2) ** BigInt(255) - BigInt(19)
    console.log(num2.toString(16))
    console.log(ED25519_P === num1)
    console.log(ED25519_P === num2)
}

function test() {
    const num1 = 0xffffffff_ffffffff_ffffffff_ffffffff_ffffffff_ffffffff_fffffffe_fffffc2fn
    const num2 = (
        2n ** 256n - 
        2n ** 32n - 
        2n ** 9n - 
        2n ** 8n - 
        2n ** 7n - 
        2n ** 6n - 
        2n ** 4n - 
        1n
    )
    console.log(num1.toString(16))
    console.log(num2.toString(16))
    console.log(num1 === num2)
}

test()
