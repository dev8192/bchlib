
const _0n = BigInt(0)
const _1n = BigInt(1)
const _2n = BigInt(2)
const _8n = BigInt(8)

