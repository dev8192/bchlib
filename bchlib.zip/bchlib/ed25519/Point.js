/*
    Point is called 8518 times
*/

class Point {
    constructor(ex, ey, ez, et) {
        this.ex = ex;
        this.ey = ey;
        this.ez = ez;
        this.et = et;
        Object.freeze(this);
    }
    get x() {
        return this.toAffine().x;
    }
    get y() {
        return this.toAffine().y;
    }
    static fromAffine(p) {
        if (p instanceof Point)
            throw new Error('extended point not allowed');
        const { x, y } = p || {};
        return new Point(x, y, _1n, modP(x * y));
    }
    static normalizeZ(points) {
        const toInv = Fp.invertBatch(points.map((p) => p.ez));
        return points.map((p, i) => p.toAffine(toInv[i])).map(Point.fromAffine);
    }
    // Multiscalar Multiplication
    static msm(points, scalars) {
        return pippenger(Point, Fn, points, scalars);
    }
    // "Private method", don't use it directly
    _setWindowSize(windowSize) {
        wnaf.setWindowSize(this, windowSize);
    }
    // Not required for fromHex(), which always creates valid points.
    // Could be useful for fromAffine().
    assertValidity() {
        assertValidMemo(this);
    }
    // Compare one point to another.
    equals(other) {
        const { ex: X1, ey: Y1, ez: Z1 } = this;
        const { ex: X2, ey: Y2, ez: Z2 } = other;
        const X1Z2 = modP(X1 * Z2);
        const X2Z1 = modP(X2 * Z1);
        const Y1Z2 = modP(Y1 * Z2);
        const Y2Z1 = modP(Y2 * Z1);
        return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
    }
    is0() {
        return this.equals(Point.ZERO);
    }
    negate() {
        // Flips point sign to a negative one (-x, y in affine coords)
        return new Point(modP(-this.ex), this.ey, this.ez, modP(-this.et));
    }
    // Fast algo for doubling Extended Point.
    // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#doubling-dbl-2008-hwcd
    // Cost: 4M + 4S + 1*a + 6add + 1*2.
    double() {
        const { a } = CURVE;
        const { ex: X1, ey: Y1, ez: Z1 } = this;
        const A = modP(X1 * X1); // A = X12
        const B = modP(Y1 * Y1); // B = Y12
        const C = modP(_2n * modP(Z1 * Z1)); // C = 2*Z12
        const D = modP(a * A); // D = a*A
        const x1y1 = X1 + Y1;
        const E = modP(modP(x1y1 * x1y1) - A - B); // E = (X1+Y1)2-A-B
        const G = D + B; // G = D+B
        const F = G - C; // F = G-C
        const H = D - B; // H = D-B
        const X3 = modP(E * F); // X3 = E*F
        const Y3 = modP(G * H); // Y3 = G*H
        const T3 = modP(E * H); // T3 = E*H
        const Z3 = modP(F * G); // Z3 = F*G
        return new Point(X3, Y3, Z3, T3);
    }
    // Fast algo for adding 2 Extended Points.
    // https://hyperelliptic.org/EFD/g1p/auto-twisted-extended.html#addition-add-2008-hwcd
    // Cost: 9M + 1*a + 1*d + 7add.
    add(other) {
        const { a, d } = CURVE;
        const { ex: X1, ey: Y1, ez: Z1, et: T1 } = this;
        const { ex: X2, ey: Y2, ez: Z2, et: T2 } = other;
        // Faster algo for adding 2 Extended Points when curve's a=-1.
        // http://hyperelliptic.org/EFD/g1p/auto-twisted-extended-1.html#addition-add-2008-hwcd-4
        // Cost: 8M + 8add + 2*2.
        // Note: It does not check whether the `other` point is valid.
        if (a === BigInt(-1)) {
            const A = modP((Y1 - X1) * (Y2 + X2));
            const B = modP((Y1 + X1) * (Y2 - X2));
            const F = modP(B - A);
            if (F === _0n)
                return this.double(); // Same point. Tests say it doesn't affect timing
            const C = modP(Z1 * _2n * T2);
            const D = modP(T1 * _2n * Z2);
            const E = D + C;
            const G = B + A;
            const H = D - C;
            const X3 = modP(E * F);
            const Y3 = modP(G * H);
            const T3 = modP(E * H);
            const Z3 = modP(F * G);
            return new Point(X3, Y3, Z3, T3);
        }
        const A = modP(X1 * X2); // A = X1*X2
        const B = modP(Y1 * Y2); // B = Y1*Y2
        const C = modP(T1 * d * T2); // C = T1*d*T2
        const D = modP(Z1 * Z2); // D = Z1*Z2
        const E = modP((X1 + Y1) * (X2 + Y2) - A - B); // E = (X1+Y1)*(X2+Y2)-A-B
        const F = D - C; // F = D-C
        const G = D + C; // G = D+C
        const H = modP(B - a * A); // H = B-a*A
        const X3 = modP(E * F); // X3 = E*F
        const Y3 = modP(G * H); // Y3 = G*H
        const T3 = modP(E * H); // T3 = E*H
        const Z3 = modP(F * G); // Z3 = F*G
        return new Point(X3, Y3, Z3, T3);
    }
    subtract(other) {
        return this.add(other.negate());
    }
    wNAF(n) {
        return wnaf.wNAFCached(this, n, Point.normalizeZ);
    }
    // Constant-time multiplication.
    multiply(scalar) {
        const n = scalar;
        aInRange('scalar', n, _1n, CURVE_ORDER); // 1 <= scalar < L
        const { p, f } = this.wNAF(n);
        return Point.normalizeZ([p, f])[0];
    }
    // Non-constant-time multiplication. Uses double-and-add algorithm.
    // It's faster, but should only be used when you don't care about
    // an exposed private key e.g. sig verification.
    // Does NOT allow scalars higher than CURVE.n.
    // Accepts optional accumulator to merge with multiply (important for sparse scalars)
    multiplyUnsafe(scalar, acc = Point.ZERO) {
        const n = scalar;
        aInRange('scalar', n, _0n, CURVE_ORDER); // 0 <= scalar < L
        if (n === _0n)
            return I;
        if (this.is0() || n === _1n)
            return this;
        return wnaf.wNAFCachedUnsafe(this, n, Point.normalizeZ, acc);
    }
    // Checks if point is of small order.
    // If you add something to small order point, you will have "dirty"
    // point with torsion component.
    // Multiplies point by cofactor and checks if the result is 0.
    isSmallOrder() {
        return this.multiplyUnsafe(cofactor).is0();
    }
    // Multiplies point by curve order and checks if the result is 0.
    // Returns `false` is the point is dirty.
    isTorsionFree() {
        return wnaf.unsafeLadder(this, CURVE_ORDER).is0();
    }
    // Converts Extended point to default (x, y) coordinates.
    // Can accept precomputed Z^-1 - for example, from invertBatch.
    toAffine(iz) {
        return toAffineMemo(this, iz);
    }
    clearCofactor() {
        const { h: cofactor } = CURVE;
        if (cofactor === _1n)
            return this;
        return this.multiplyUnsafe(cofactor);
    }
    // Converts hash string or Uint8Array to Point.
    // Uses algo from RFC8032 5.1.3.
    static fromHex(hex, zip215 = false) {
        const { d, a } = CURVE;
        const len = Fp.BYTES;
        hex = ensureBytes('pointHex', hex, len); // copy hex to a new array
        abool('zip215', zip215);
        const normed = hex.slice(); // copy again, we'll manipulate it
        const lastByte = hex[len - 1]; // select last byte
        normed[len - 1] = lastByte & ~0x80; // clear last bit
        const y = bytesToNumberLE(normed);
        // zip215=true is good for consensus-critical apps. =false follows RFC8032 / NIST186-5.
        // RFC8032 prohibits >= p, but ZIP215 doesn't
        // zip215=true:  0 <= y < MASK (2^256 for ed25519)
        // zip215=false: 0 <= y < P (2^255-19 for ed25519)
        const max = zip215 ? MASK : Fp.ORDER;
        aInRange('pointHex.y', y, _0n, max);
        // Ed25519: x² = (y²-1)/(dy²+1) mod p. Ed448: x² = (y²-1)/(dy²-1) mod p. Generic case:
        // ax²+y²=1+dx²y² => y²-1=dx²y²-ax² => y²-1=x²(dy²-a) => x²=(y²-1)/(dy²-a)
        const y2 = modP(y * y); // denominator is always non-0 mod p.
        const u = modP(y2 - _1n); // u = y² - 1
        const v = modP(d * y2 - a); // v = d y² + 1.
        let { isValid, value: x } = uvRatio(u, v); // √(u/v)
        if (!isValid)
            throw new Error('Point.fromHex: invalid y coordinate');
        const isXOdd = (x & _1n) === _1n; // There are 2 square roots. Use x_0 bit to select proper
        const isLastByteOdd = (lastByte & 0x80) !== 0; // x_0, last bit
        if (!zip215 && x === _0n && isLastByteOdd)
            // if x=0 and x_0 = 1, fail
            throw new Error('Point.fromHex: x=0 and x_0=1');
        if (isLastByteOdd !== isXOdd)
            x = modP(-x); // if x_0 != x mod 2, set x = p-x
        return Point.fromAffine({ x, y });
    }
    static fromPrivateKey(privKey) {
        return getExtendedPublicKey(privKey).point;
    }
    toRawBytes() {
        const { x, y } = this.toAffine();
        const bytes = numberToBytesLE(y, Fp.BYTES); // each y has 2 x values (x, -y)
        bytes[bytes.length - 1] |= x & _1n ? 0x80 : 0; // when compressing, it's enough to store y
        return bytes; // and use the last byte to encode sign of x
    }
    toHex() {
        return bytesToHex(this.toRawBytes()); // Same as toRawBytes, but returns string.
    }
}
