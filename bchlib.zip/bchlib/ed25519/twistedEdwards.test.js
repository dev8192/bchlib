/*
    <script src="sha512\sha512.js"></script>
    <script src="ed25519\common.js"></script>
    <script src="ed25519\ed25519Defaults.js"></script>
    <script src="ed25519\validateOpts.js"></script>
    <script src="ed25519\twistedEdwards.js"></script>
    <script src="ed25519\twistedEdwards.test.js"></script>
*/


function test() {
    const privateScalar = ed25519.utils.randomPrivateKey()
    console.log(privateScalar)

    const publicKey = ed25519.getPublicKey(privateScalar)
    console.log(publicKey)
}

test()
