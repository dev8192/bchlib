/*
    There seems to be a native solution
*/

function test1() {
    const { generateKeyPairSync } = require('crypto')
    const { publicKey, privateKey } = generateKeyPairSync('ed25519')
    console.log(publicKey)
    console.log(privateKey)
}

async function test() {
    const result = await crypto.subtle.generateKey(
        { name: 'Ed25519' }, 
        true, 
        ['sign', 'verify']
    )
    console.log(result)
}

test()
