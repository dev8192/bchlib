
const asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
function asciiToBase16(ch) {
    if (ch >= asciis._0 && ch <= asciis._9)
        return ch - asciis._0; // '2' => 50-48
    if (ch >= asciis.A && ch <= asciis.F)
        return ch - (asciis.A - 10); // 'B' => 66-(65-10)
    if (ch >= asciis.a && ch <= asciis.f)
        return ch - (asciis.a - 10); // 'b' => 98-(97-10)
    return;
}

function test1() {
    console.log(asciiToBase16(47))
    console.log(asciiToBase16(48))
    console.log(asciiToBase16(49))
    
    // console.log(asciiToBase16(64))
    // console.log(asciiToBase16(65))
    // console.log(asciiToBase16(66))
    
    console.log(asciiToBase16('A'))
    console.log(asciiToBase16('B'))
    
    console.log(asciiToBase16(96))
    console.log(asciiToBase16(97))
    console.log(asciiToBase16(98))
    
    console.log('b' >= 97)
    console.log('b'.charCodeAt() >= 97)
}

function test() {
    const hex = '0123456789abcdef'
    for (let i = 0; i < hex.length; i += 2) {
        const n1 = asciiToBase16(hex.charCodeAt(i))
        const n2 = asciiToBase16(hex.charCodeAt(i + 1))
        console.log(n1, n2)
    }
}

test()
