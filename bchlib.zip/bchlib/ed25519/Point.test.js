/*
    <script src="ed25519\Point.js"></script>
    <script src="ed25519\Point.test.js"></script>
*/

const _0n = BigInt(0)
const _1n = BigInt(1)

function mod(a, b) {
    const result = a % b;
    return result >= _0n ? result : b + result;
}

const ORDER = BigInt('57896044618658097711785492504343953926634992332820282019728792003956564819949')
const modP = (num) => mod(num, ORDER)

/*
    Base point (x, y) aka generator point
*/
function test() {
    const CURVE = {
        Gx: BigInt('15112221349535400772501151409588531511454012693041857206046113283949847762202'),
        Gy: BigInt('46316835694926478169428394003475163141307993866256225615783033603165251855960'),
    }
    const pt1 = new Point(CURVE.Gx, CURVE.Gy, _1n, modP(CURVE.Gx * CURVE.Gy))
    const pt2 = new Point(CURVE.Gx + BigInt(1), CURVE.Gy, _1n, modP(CURVE.Gx * CURVE.Gy))
    debugger
    console.log(pt1.equals(pt2))
}

test()
