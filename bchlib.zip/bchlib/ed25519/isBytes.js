/*
There is no 'a' such that
(a instanceof Uint8Array) is false
and (ArrayBuffer.isView(a) && a.constructor.name === 'Uint8Array') is true
*/

function isBytes(a) {
    return a instanceof Uint8Array || (ArrayBuffer.isView(a) && a.constructor.name === 'Uint8Array');
}

function test() {
    const arr = new Uint8Array()
    console.log(isBytes(arr))
    console.log(arr instanceof Uint8Array)
    console.log(ArrayBuffer.isView(arr) && arr.constructor.name === 'Uint8Array')
}

test()
