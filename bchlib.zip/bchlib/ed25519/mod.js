/*
    Modular arithmetic
*/

const _0n = BigInt(0)

/*
    Called 85111 times
    (10845 times with negative numbers)
*/
function mod(a, b) {
    const result = a % b
    if (result >= _0n) {
        return result
    }
    return b + result
}

const CURVE_ORDER = BigInt('7237005577332262213973186563042994240857116359379907606001950938285454250989')
function modN(a) {
    return mod(a, CURVE_ORDER);
}

function test1() {
    console.log(5 % 15, mod(5, 15))
    console.log(20 % 15, mod(20, 15))
    console.log(35 % 15, mod(35, 15))
    console.log(50 % 15, mod(50, 15))
}

function test() {
    console.log(-5 % 15, mod(-5, 15))
    console.log(-20 % 15, mod(-20, 15))
    console.log(-35 % 15, mod(-35, 15))
    console.log(-50 % 15, mod(-50, 15))
}

function test1() {
    console.log(mod(BigInt(10), BigInt(15)))
}

function test1() {
    console.log(modN(BigInt(10)))
    console.log(modN(BigInt(12345)))
    console.log(modN(CURVE_ORDER + BigInt(12345)))
}

test()
