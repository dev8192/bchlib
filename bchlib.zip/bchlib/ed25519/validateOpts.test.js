/*
    <script src="sha512\sha512.js"></script>
    <script src="ed25519\common.js"></script>
    <script src="ed25519\ed25519Defaults.js"></script>
    <script src="ed25519\validateOpts.js"></script>
    <script src="ed25519\validateOpts.test.js"></script>
*/

function test() {
    debugger
    const CURVE = validateOpts(ed25519Defaults)
    console.log(ed25519Defaults)
    console.log(CURVE)
}

test()
