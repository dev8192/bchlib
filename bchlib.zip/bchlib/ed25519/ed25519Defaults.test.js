/*
    <script src="sha512\sha512.js"></script>
    <script src="ed25519\common.js"></script>
    <script src="ed25519\ed25519Defaults.js"></script>
    <script src="ed25519\ed25519Defaults.test.js"></script>
*/

function test() {
    console.log(ed25519Defaults.a)
}

test()
