/*
    <script src="solana.js"></script>
    <script src="Keypair\fromSeed.js"></script>
*/

function test() {
    const seed = new Uint8Array([
        142,  94, 237,  59, 223,  28,  31, 119,
        140,  98,  69,  42,  58, 174, 253,  20,
        20,  29,  66, 138, 169,  98, 134,   5,
        40, 116,  36,   0,  77, 182,   8,  11
    ])
    const keypair = solanaWeb3.Keypair.fromSeed(seed)
    const publicKey = keypair.publicKey.toString()
    // const publicKey = keypair.publicKey.toBase58()
    console.log('Public Key:', publicKey)
    const secretKey = Array.from(keypair.secretKey)
    console.log('Secret Key:', secretKey)
}

test()
