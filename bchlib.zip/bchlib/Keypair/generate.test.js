/*
    This program shows how to generate a new keypair
*/

function test() {
    const keypair = solanaWeb3.Keypair.generate()
    console.log(keypair)
    console.log(keypair._keypair.publicKey)
    console.log(keypair._keypair.secretKey)
}

function test1() {
    const keypair = solanaWeb3.Keypair.generate()
    const publicKey = keypair.publicKey.toBase58()
    console.log("Public Key (Base58)", publicKey)

    // const publicKeyBytes = Array.from(keypair.publicKey.toBytes())
    // console.log("Public Key (Bytes)", publicKeyBytes)
}

function test1() {
    const keypair = solanaWeb3.Keypair.generate()
    const secretKey = Array.from(keypair.secretKey)
    console.log("Private Key (Secret Key)", secretKey)
    console.log("Private Key Length", secretKey.length + " bytes")
}


test()
