

class Keypair {
    constructor(keypair) {
        this._keypair = keypair ?? generateKeypair();
    }
    static generate() {
        return new Keypair(generateKeypair());
    }
    static fromSecretKey(secretKey, options) {
        if (secretKey.byteLength !== 64) {
            throw new Error('bad secret key size');
        }
        const publicKey = secretKey.slice(32, 64);
        if (!options || !options.skipValidation) {
            const privateScalar = secretKey.slice(0, 32);
            const computedPublicKey = getPublicKey(privateScalar);
            for (let ii = 0; ii < 32; ii++) {
                if (publicKey[ii] !== computedPublicKey[ii]) {
                    throw new Error('provided secretKey is invalid');
                }
            }
        }
        return new Keypair({
            publicKey,
            secretKey
        });
    }
    static fromSeed(seed) {
        const publicKey = getPublicKey(seed);
        const secretKey = new Uint8Array(64);
        secretKey.set(seed);
        secretKey.set(publicKey, 32);
        return new Keypair({
            publicKey,
            secretKey
        });
    }
    get publicKey() {
        return new PublicKey(this._keypair.publicKey);
    }
    get secretKey() {
        return new Uint8Array(this._keypair.secretKey);
    }
}

