/*
    Use this to create an actual key pair
*/

function test() {
    const keypair = solanaWeb3.Keypair.generate()
    const publicKey = keypair.publicKey.toString()
    console.log(publicKey)
    const secretKey = Array.from(keypair.secretKey)
    console.log(secretKey)
}

test()
