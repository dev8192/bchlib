

var DNS = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';
var URL = '6ba7b811-9dad-11d1-80b4-00c04fd430c8';
function v35(name, version, hashfunc) {
    function generateUUID(value, namespace, buf, offset) {
        if (typeof value === 'string') {
            value = stringToBytes(value);
        }

        if (typeof namespace === 'string') {
            namespace = parse(namespace);
        }

        if (namespace.length !== 16) {
            throw TypeError('Namespace must be array-like (16 iterable integer values, 0-255)');
        } // Compute hash of namespace and value, Per 4.3
        // Future: Use spread syntax when supported on all platforms, e.g. `bytes =
        // hashfunc([...namespace, ... value])`


        var bytes = new Uint8Array(16 + value.length);
        bytes.set(namespace);
        bytes.set(value, namespace.length);
        bytes = hashfunc(bytes);
        bytes[6] = bytes[6] & 0x0f | version;
        bytes[8] = bytes[8] & 0x3f | 0x80;

        if (buf) {
            offset = offset || 0;

            for (var i = 0; i < 16; ++i) {
                buf[offset + i] = bytes[i];
            }

            return buf;
        }

        return stringify(bytes);
    }

    try {
        generateUUID.name = name;
    } catch (err) { }

    generateUUID.DNS = DNS;
    generateUUID.URL = URL;
    return generateUUID;
}

function md5() {

}
var v3 = v35('v3', 0x30, md5);

function sha1() {

}
var v5 = v35('v5', 0x50, sha1);


