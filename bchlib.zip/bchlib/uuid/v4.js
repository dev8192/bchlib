
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
    if (!getRandomValues) {
        getRandomValues = (
            (
                typeof crypto !== 'undefined' && 
                crypto.getRandomValues && 
                crypto.getRandomValues.bind(crypto) 
            ) || (
                typeof msCrypto !== 'undefined' && 
                typeof msCrypto.getRandomValues === 'function' && 
                msCrypto.getRandomValues.bind(msCrypto)
            )
        )

        if (!getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported.')
        }
    }

    return getRandomValues(rnds8)
}

function v4(options, buf, offset) {
    options = options || {};
    var rnds = options.random || (options.rng || rng)();

    rnds[6] = rnds[6] & 0x0f | 0x40;
    rnds[8] = rnds[8] & 0x3f | 0x80;

    if (buf) {
        offset = offset || 0;

        for (var i = 0; i < 16; ++i) {
            buf[offset + i] = rnds[i];
        }

        return buf;
    }

    return stringify(rnds);
}
