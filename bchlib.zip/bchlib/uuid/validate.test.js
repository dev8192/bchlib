/*
    <script src="uuid\validate.js"></script>
    <script src="uuid\validate.test.js"></script>
*/

function test() {
    console.log(validate('e9147cdc-2c92-4ea7-a232-3135d6cade7b'))
    console.log(validate('xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'))
}

test()
