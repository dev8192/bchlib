/*
    <script src="uuid\stringify.js"></script>
    <script src="uuid\validate.js"></script>
    <script src="uuid\v4.js"></script>
    <script src="uuid\v4.test.js"></script>
*/

function test1() {
    console.log(v4())
    console.log(v4())
    console.log(v4())
}

function test() {
    console.log(v4({
        random: [
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
        ]
    }))
    console.log(v4({
        random: [
            0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 
        ]
    }))
}

test()
