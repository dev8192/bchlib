/*
    NOTE: Neither v3, nor v5 are used in solana.
    Nevertheless these algorithms are good to know
    for everyone wishing to master the blockchain technology.

    <script src="uuid\stringify.js"></script>
    <script src="md5\md5.js"></script>
    <script src="sha1\sha1.js"></script>
    <script src="uuid\v35.js"></script>
    <script src="uuid\v35.test.js"></script>
*/

function test() {
    const value = fff
    const namespace = fff
    const buf = fff
    const offset = fff
    
    const uuid_v3 = v3(value, namespace, buf, offset)
    console.log(uuid_v3)

    const uuid_v5 = v5(value, namespace, buf, offset)
    console.log(uuid_v5)
}

test()
