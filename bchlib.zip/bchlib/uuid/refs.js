/*
    Sources of inspiration for UUID:
    
    https://github.com/LiosK/UUID.js
    http://docs.python.org/library/uuid.html
    https://github.com/uuidjs/uuid

*/