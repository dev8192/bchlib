/*
I have a signature. give me a program that prints info about its status. no css and html. only simple js
*/




async function test() {
    const signature = '4eHW4tBH1gyYSHhzZr7fYB7v9QcpdBxkN9qtYri3xBPJ4v2fAmATYq839FtLHsU5jWy3CH4bkLgR65Jw7xbwTVp5'
    const connection = new solanaWeb3.Connection(
        // solanaWeb3.clusterApiUrl('mainnet-beta'),
        solanaWeb3.clusterApiUrl('devnet'),
        // solanaWeb3.clusterApiUrl('testnet'),
        'confirmed'
    )

    const tx = await connection.getTransaction(signature, {
        commitment: 'confirmed',
        maxSupportedTransactionVersion: 0
    })

    if (!tx) {
        console.log('Transaction not found')
        return
    }
    console.log(tx)

    console.log('Signature:', signature)
    console.log('Slot:', tx.slot)
    console.log('Block Time:', new Date((tx.blockTime || 0) * 1000).toISOString())
    if (tx.meta) {
        console.log('Fee:', tx.meta.fee)
        if (tx.meta.err) {
            console.log('Error:', JSON.stringify(tx.meta.err))
        } else {
            console.log('Success')
        }
    }

    console.log(JSON.stringify(tx.transaction.message.accountKeys, null, 4))

    console.log('Accounts:')
    for (let i = 0; i < tx.transaction.message.accountKeys.length; i++) {
        const key = tx.transaction.message.accountKeys[i]
        const isWritable = tx.transaction.message.isAccountWritable(i)
        const signer = tx.transaction.message.isAccountSigner(i)
        console.log(i, key.toBase58(), 'signer:', signer, 'isWritable:', isWritable)
    }
}

test()
