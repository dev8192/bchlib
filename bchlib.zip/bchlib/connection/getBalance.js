/*
    <script src="solana.js"></script>
    <script src="airdrop\getBalance.js"></script>
*/

async function test() {
    const WALLET_ADDRESS = '8gTuryixSm85DmeB2Rp44nwh5M1kUz7bHHdoT8e3RMmD'
    
    const connection = new solanaWeb3.Connection(
        // solanaWeb3.clusterApiUrl('mainnet-beta'),
        // solanaWeb3.clusterApiUrl('testnet'),
        solanaWeb3.clusterApiUrl('devnet'),
        'confirmed'
    )
    try {
        const publicKey = new solanaWeb3.PublicKey(WALLET_ADDRESS)
        const balanceLamports = await connection.getBalance(publicKey)
        
        console.log('Balance', balanceLamports)
        console.log('Balance', balanceLamports / solanaWeb3.LAMPORTS_PER_SOL)
    } catch (error) {
        console.log(error)
    }
}

test()
