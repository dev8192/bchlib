
async function test() {
    const signature = '4eHW4tBH1gyYSHhzZr7fYB7v9QcpdBxkN9qtYri3xBPJ4v2fAmATYq839FtLHsU5jWy3CH4bkLgR65Jw7xbwTVp5'
    const connection = new solanaWeb3.Connection(
        // solanaWeb3.clusterApiUrl('mainnet-beta'),
        solanaWeb3.clusterApiUrl('devnet'),
        // solanaWeb3.clusterApiUrl('testnet'),
        'confirmed'
    )
    const status = await connection.getSignatureStatus(signature)
    console.log(JSON.stringify(status, null, 4))
    // console.log(status.value?.confirmationStatus)
}

test()

