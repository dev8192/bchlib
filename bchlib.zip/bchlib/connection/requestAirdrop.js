
const signatures = [
    '39QCb3Kg2hvBwprGmZ8vN9huCfQaXT92rLHRhj2RBgVisz1zQktLvGJj5GYWYngBmzysHWnc9gWQL1yPFoah7zZt',
    'fff',
    'fff',
    'fff',
]

async function test() {
    const WALLET_PUBLIC_KEY = '6tfo2yWskkRT4zYcc8zQkTog8vADwyqBNbEJ1ftji2PB'
    try {
        const publicKey = new solanaWeb3.PublicKey(WALLET_PUBLIC_KEY)
        
        const connection = new solanaWeb3.Connection(
            // solanaWeb3.clusterApiUrl('testnet'),
            solanaWeb3.clusterApiUrl('devnet'),
            'confirmed'
        )

        const signature = await connection.requestAirdrop(
            publicKey,
            solanaWeb3.LAMPORTS_PER_SOL
        )

        console.log('signature', signature)

        await connection.confirmTransaction(signature)
        console.log('Airdrop confirmed! Check your balance.')

        console.log('done')
    } catch (error) {
        console.error('Airdrop failed:', error)
    }
}

test()
